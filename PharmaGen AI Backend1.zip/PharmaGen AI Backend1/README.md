# PharmaGen AI Backend

A modular Python backend prototype for the EY Techathon, implementing an AI-powered pharmaceutical portfolio strategy orchestrator. This system uses a master-agent architecture to coordinate multiple specialized worker agents that analyze market data, patents, clinical trials, trade information, and internal knowledge to generate comprehensive strategic reports.

## Architecture Summary

The system follows a master-worker agent pattern where the **Master Agent (Portfolio Strategy Orchestrator)** decomposes user queries and coordinates specialized agents: **IQVIA Insights Agent** (market analysis), **EXIM Trade Agent** (trade data), **Patent Landscape Agent** (IP analysis), **Clinical Trials Agent** (trial data), **Web Intelligence Agent** (external research), and **Internal Knowledge Agent** (corporate documents). Each agent processes mock data from `/mock_data` and uses an optional LLM wrapper for intelligent summarization. The **Report Generator Agent** consolidates all findings into structured text/PDF reports. The architecture is designed for easy extension with real APIs (IQVIA, USPTO, ClinicalTrials.gov, Pinecone) while maintaining a fully functional prototype using mock data.

## Setup & Installation

1. **Create a virtual environment:**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Set up environment variables (optional):**
   ```bash
   cp .env.example .env
   # Edit .env and add OPENAI_API_KEY if you want to use real LLM calls
   ```

4. **Run the server:**
   ```bash
   uvicorn app:app --reload
   ```
   Or use the helper script:
   ```bash
   bash run.sh  # On Windows, use Git Bash or run commands manually
   ```

The server will start on `http://localhost:8000`

## API Usage

### POST /analyze

Analyze a pharmaceutical query using the multi-agent system.

**Request Body:**
```json
{
  "query": "Analyze market opportunities for diabetes treatments",
  "molecule": "Metformin",
  "therapeutic_area": "Diabetes"
}
```

**Example using curl:**
```bash
curl -X POST "http://localhost:8000/analyze" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "What are the market trends for oncology drugs?",
    "molecule": "Pembrolizumab",
    "therapeutic_area": "Oncology"
  }'
```

**Example using httpie:**
```bash
http POST http://localhost:8000/analyze \
  query="Analyze competitive landscape for cardiovascular drugs" \
  molecule="Atorvastatin" \
  therapeutic_area="Cardiovascular"
```

**Response:**
```json
{
  "status": "ok",
  "summary": "Analysis completed successfully...",
  "agent_outputs": {
    "iqvia": {...},
    "exim": {...},
    "patent": {...},
    ...
  },
  "report_path": "report_output/report_20240101_120000.txt"
}
```

## Project Structure

```
.
├── app.py                      # FastAPI application entry point
├── master_agent.py             # Master orchestrator agent
├── agents/                     # Worker agent implementations
│   ├── iqvia_agent.py
│   ├── exim_agent.py
│   ├── patent_agent.py
│   ├── clinical_agent.py
│   ├── web_intel_agent.py
│   ├── internal_agent.py
│   └── report_generator_agent.py
├── llm/                        # LLM wrapper (optional OpenAI integration)
│   └── llm_client.py
├── vector_store/               # Vector store placeholder (for Pinecone/FAISS)
│   └── vector_store.py
├── mock_data/                  # Mock data files for prototype
│   ├── iqvia.json
│   ├── exim.json
│   ├── patents.json
│   ├── clinical_trials.json
│   ├── web_results.json
│   └── internal_docs/
├── utils/                      # Utility functions
│   └── helpers.py
├── report_output/              # Generated reports directory
└── tests/                      # Test scripts
    └── test_flow.py
```

## Testing

Run the test script to verify the system:
```bash
python tests/test_flow.py
```

## Important Notes

- **This is a prototype** using mock data. Real paid integrations (IQVIA, USPTO, ClinicalTrials.gov) are replaced by mock files for the EY Techathon demonstration.
- The LLM wrapper (`llm/llm_client.py`) will use real OpenAI API calls only if `OPENAI_API_KEY` is set in the environment. Otherwise, it returns deterministic mock responses.
- All external API integrations are clearly marked with comments indicating where real implementations should be added.
- The vector store is a simple in-memory placeholder. Replace with Pinecone or FAISS for production use.

## Next Steps

1. Implement detailed task decomposition logic in `master_agent.py`
2. Enhance individual worker agents with more sophisticated analysis
3. Integrate real APIs (IQVIA, USPTO, ClinicalTrials.gov)
4. Replace vector store placeholder with Pinecone or FAISS
5. Add authentication and rate limiting
6. Implement caching for frequently accessed data







