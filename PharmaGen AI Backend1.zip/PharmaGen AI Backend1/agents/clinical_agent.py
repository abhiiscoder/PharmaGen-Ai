"""
Clinical Trials Agent – assesses pipeline saturation and development intensity.
"""

import json
import os
from typing import Dict, Any, List, Set
import logging

from llm.llm_client import call_llm

logger = logging.getLogger(__name__)


def analyze_clinical(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Analyze clinical trial data to assess pipeline saturation and development intensity.
    
    Filters trials by molecule and therapeutic_area, counts trials by phase,
    and determines clinical saturation level.
    
    Args:
        payload: Request payload with query, molecule, therapeutic_area
        
    Returns:
        Structured analysis with summary, table (phase_1, phase_2, phase_3, 
        clinical_saturation), and details (key_sponsors)
    """
    logger.info("Clinical Trials Agent: Starting pipeline analysis")
    
    # Load mock data
    mock_data_path = os.path.join(os.path.dirname(__file__), "..", "mock_data", "clinical_trials.json")
    
    with open(mock_data_path, "r") as f:
        clinical_data = json.load(f)
    
    # Filter data based on query parameters
    molecule = payload.get("molecule", "").strip()
    therapeutic_area = payload.get("therapeutic_area", "").strip()
    
    filtered_data = clinical_data
    
    # Filter by therapeutic_area (primary filter)
    if therapeutic_area:
        therapeutic_area_lower = therapeutic_area.lower()
        filtered_data = [
            d for d in filtered_data 
            if therapeutic_area_lower in d.get("condition", "").lower()
        ]
    
    # Further filter by molecule if provided
    if molecule and filtered_data:
        molecule_lower = molecule.lower()
        molecule_filtered = [
            d for d in filtered_data 
            if molecule_lower in d.get("drug_name", "").lower() or 
               molecule_lower in d.get("intervention", "").lower()
        ]
        if molecule_filtered:
            filtered_data = molecule_filtered
    
    # If no matches, use all data as default
    if not filtered_data:
        filtered_data = clinical_data
    
    # Count trials by phase
    phase_1_trials = 0
    phase_2_trials = 0
    phase_3_trials = 0
    key_sponsors_set: Set[str] = set()
    
    for trial in filtered_data:
        phase = trial.get("phase", "").lower()
        sponsor = trial.get("sponsor", "")
        
        # Count by phase
        if "phase i" in phase or "phase 1" in phase:
            phase_1_trials += 1
        elif "phase ii" in phase or "phase 2" in phase:
            phase_2_trials += 1
        elif "phase iii" in phase or "phase 3" in phase:
            phase_3_trials += 1
        elif "phase iv" in phase or "phase 4" in phase:
            # Phase IV trials are post-marketing, count as Phase 3 for saturation analysis
            phase_3_trials += 1
        
        # Collect unique sponsors
        if sponsor:
            key_sponsors_set.add(sponsor)
    
    # Determine clinical saturation
    clinical_saturation = "High" if phase_3_trials >= 3 else "Low"
    
    # Convert sponsors set to sorted list
    key_sponsors = sorted(list(key_sponsors_set))
    
    # Generate pipeline summary using LLM
    context = {
        "phase_1": phase_1_trials,
        "phase_2": phase_2_trials,
        "phase_3": phase_3_trials,
        "clinical_saturation": clinical_saturation,
        "key_sponsors": key_sponsors
    }
    
    prompt = f"Provide a 2-3 line executive summary of clinical pipeline saturation. " \
             f"Phase 1: {phase_1_trials}, Phase 2: {phase_2_trials}, Phase 3: {phase_3_trials}, " \
             f"Saturation: {clinical_saturation}. Highlight development intensity and competitive landscape."
    
    summary = call_llm(prompt, context)
    
    logger.info(f"Clinical Trials Agent: Analyzed {len(filtered_data)} trials - P1:{phase_1_trials}, P2:{phase_2_trials}, P3:{phase_3_trials}")
    
    # Calculate score based on phase maturity, saturation, biological plausibility (0-100)
    score = 50  # Base score
    
    # Question-conditioned scoring adjustments
    query_lower = (payload.get("query", "") or payload.get("question", "")).lower()
    molecule = payload.get("molecule", "").lower()
    therapeutic_area = payload.get("therapeutic_area", "").lower()
    
    # Phase maturity factor (higher phase = more mature)
    total_trials = phase_1_trials + phase_2_trials + phase_3_trials
    if total_trials > 0:
        phase_maturity = (phase_1_trials * 0.2 + phase_2_trials * 0.5 + phase_3_trials * 1.0) / total_trials
        score += int(phase_maturity * 30)
    
    # Question context adjustments
    is_late_stage_question = any(word in query_lower for word in ["phase 3", "phase iii", "late stage", "near market", "approval"])
    is_early_stage_question = any(word in query_lower for word in ["phase 1", "phase i", "early stage", "preclinical", "discovery"])
    is_repurposing = any(word in query_lower for word in ["repurpose", "reposition", "existing drug"])
    
    if is_late_stage_question:
        # Late-stage questions: Phase 3 trials are critical
        if phase_3_trials >= 3:
            score += 10
        elif phase_3_trials == 0:
            score -= 15
    elif is_early_stage_question:
        # Early-stage questions: Phase 1/2 activity is valuable
        if phase_1_trials + phase_2_trials >= 2:
            score += 10
        elif total_trials == 0:
            score -= 10
    if is_repurposing:
        # Repurposing: existing Phase 3 data is highly valuable
        if phase_3_trials >= 1:
            score += 15
    
    # Saturation factor (moderate saturation is good, high is concerning)
    if clinical_saturation == "Low":
        score += 15
    elif clinical_saturation == "High":
        score -= 15
    
    # Biological plausibility proxy (more sponsors = more validation)
    if len(key_sponsors) >= 5:
        score += 10
    elif len(key_sponsors) >= 2:
        score += 5
    
    score = max(0, min(100, score))
    
    # Determine risk level
    if score >= 70:
        risk_level = "Low"
    elif score >= 40:
        risk_level = "Moderate"
    else:
        risk_level = "High"
    
    # Generate key signal based on context
    if phase_3_trials >= 3 and clinical_saturation == "Low":
        key_signal = f"Active Phase 3 pipeline ({phase_3_trials} trials) with low saturation indicates strong development momentum and market validation"
    elif phase_3_trials > 0 and clinical_saturation == "Low":
        key_signal = f"Phase 3 activity ({phase_3_trials} trials) with manageable saturation suggests viable development pathway"
    elif phase_2_trials >= 2:
        key_signal = f"Multiple Phase 2 trials ({phase_2_trials}) indicate progressing validation with moderate maturity"
    elif clinical_saturation == "High":
        key_signal = f"High clinical saturation suggests competitive landscape but validates market interest"
    else:
        key_signal = f"Early-stage pipeline (P1:{phase_1_trials}, P2:{phase_2_trials}) requires further validation for maturity assessment"
    
    # Generate justification
    justification_parts = []
    if phase_3_trials >= 3:
        justification_parts.append(f"Strong Phase 3 presence ({phase_3_trials} trials) demonstrates late-stage maturity")
    elif phase_3_trials > 0:
        justification_parts.append(f"Phase 3 activity ({phase_3_trials} trials) indicates advancing development")
    if clinical_saturation == "Low":
        justification_parts.append(f"Low saturation enables differentiation and market entry")
    elif clinical_saturation == "High":
        justification_parts.append(f"High saturation suggests competitive intensity but validates market opportunity")
    if len(key_sponsors) >= 5:
        justification_parts.append(f"Multiple sponsors ({len(key_sponsors)}) indicate broad industry interest and biological plausibility")
    elif len(key_sponsors) >= 2:
        justification_parts.append(f"Multiple sponsors ({len(key_sponsors)}) suggest credible development rationale")
    
    justification = ". ".join(justification_parts) if justification_parts else f"Clinical pipeline analysis shows {risk_level.lower()} development risk with {total_trials} total trials across phases"
    
    # Calculate intent_relevance based on question intent
    question_intent = payload.get("question_intent", "CLINICAL_SUCCESS_PROBABILITY")
    intent_relevance = 1.0  # Default high relevance for clinical agent
    
    if question_intent == "CLINICAL_SUCCESS_PROBABILITY":
        intent_relevance = 1.0  # Maximum relevance
    elif question_intent == "REPURPOSING_FEASIBILITY":
        intent_relevance = 0.9  # High relevance (MoA transferability)
    elif question_intent == "TIME_TO_MARKET_OPTIMIZATION":
        intent_relevance = 0.8  # High relevance (development speed)
    elif question_intent == "MARKET_ACCESS_RISK":
        intent_relevance = 0.4  # Lower relevance (efficacy matters but payer is primary)
    elif question_intent == "COMMERCIAL_VALUE_MAXIMIZATION":
        intent_relevance = 0.6  # Moderate relevance (differentiation matters)
    elif question_intent == "IP_OR_EXCLUSIVITY_RISK":
        intent_relevance = 0.3  # Low relevance
    elif question_intent == "PORTFOLIO_PRIORITIZATION":
        intent_relevance = 0.7  # Moderate-high relevance
    
    # Generate blocking_issue
    blocking_issue = ""
    if risk_level == "High" or score < 40:
        if clinical_saturation == "High":
            blocking_issue = f"High clinical saturation ({phase_3_trials} Phase 3 trials) creates competitive barriers"
        elif phase_3_trials == 0 and total_trials < 3:
            blocking_issue = f"Insufficient clinical maturity ({total_trials} total trials) limits validation"
        elif score < 40:
            blocking_issue = f"Weak clinical signal (score: {score}/100) requires further validation"
        else:
            blocking_issue = f"Clinical risk profile ({risk_level}) constrains development pathway"
    
    # Generate confidence_note
    if score >= 70:
        confidence_note = f"High confidence in clinical rationale (score: {score}/100) based on {phase_3_trials} Phase 3 trials and {risk_level.lower()} risk"
    elif score >= 50:
        confidence_note = f"Moderate confidence in clinical rationale (score: {score}/100) with {total_trials} total trials across phases"
    else:
        confidence_note = f"Low confidence in clinical rationale (score: {score}/100) requires further validation"
    
    return {
        "agent": "clinical",
        "summary": summary,
        "table": {
            "phase_1": phase_1_trials,
            "phase_2": phase_2_trials,
            "phase_3": phase_3_trials,
            "clinical_saturation": clinical_saturation
        },
        "details": {
            "key_sponsors": key_sponsors
        },
        "score": score,
        "risk_level": risk_level,
        "confidence_weight": 0.30,
        "intent_relevance": intent_relevance,
        "key_signal": key_signal,
        "blocking_issue": blocking_issue,
        "confidence_note": confidence_note,
        "justification": justification
    }


# Clinical Trials Agent ready for EY Techathon demo.

