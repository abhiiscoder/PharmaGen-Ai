"""
EXIM Trade Agent – evaluates supply-chain feasibility and trade risk.
"""

import json
import os
from typing import Dict, Any, List
import logging

from llm.llm_client import call_llm

logger = logging.getLogger(__name__)


def analyze_exim(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Analyze export/import trade data to evaluate supply-chain feasibility.
    
    Filters data by molecule, analyzes import dependency, identifies key sourcing
    countries, and assesses supply risk.
    
    Args:
        payload: Request payload with query, molecule, therapeutic_area
        
    Returns:
        Structured analysis with summary, table (import_dependency, 
        top_exporting_countries), and details (supply_risk)
    """
    logger.info("EXIM Trade Agent: Starting trade analysis")
    
    # Load mock data
    mock_data_path = os.path.join(os.path.dirname(__file__), "..", "mock_data", "exim.json")
    
    with open(mock_data_path, "r") as f:
        exim_data = json.load(f)
    
    # Filter data based on molecule (primary filter for trade analysis)
    molecule = payload.get("molecule", "").strip()
    
    filtered_data = exim_data
    
    # If molecule provided, try to match by category (since molecule not directly in trade data)
    # In real scenario, trade data would have molecule mapping
    # For now, use therapeutic_area as proxy if molecule is provided
    if molecule:
        therapeutic_area = payload.get("therapeutic_area", "").strip()
        if therapeutic_area:
            therapeutic_area_lower = therapeutic_area.lower()
            filtered_data = [
                d for d in filtered_data 
                if therapeutic_area_lower in d.get("category", "").lower()
            ]
    
    # If no matches, use first entry as default
    if not filtered_data:
        filtered_data = exim_data[:1] if exim_data else []
    
    # Analyze trade data
    if filtered_data:
        primary_record = filtered_data[0]
        
        import_value = primary_record.get("import_value_usd_millions", 0)
        export_value = primary_record.get("export_value_usd_millions", 0)
        trade_balance = primary_record.get("trade_balance_usd_millions", 0)
        top_import_source = primary_record.get("top_import_source", "N/A")
        top_export_destination = primary_record.get("top_export_destination", "N/A")
        growth_trend = primary_record.get("growth_trend", "stable")
        
        # Calculate import dependency ratio
        total_trade = import_value + export_value
        if total_trade > 0:
            import_ratio = (import_value / total_trade) * 100
        else:
            import_ratio = 0
        
        # Determine import dependency level
        if import_ratio > 60:
            import_dependency = "High"
        elif import_ratio > 40:
            import_dependency = "Medium"
        else:
            import_dependency = "Low"
        
        # Identify key sourcing countries (top import sources)
        key_sourcing_countries = [top_import_source] if top_import_source != "N/A" else []
        
        # Assess supply risk based on import dependency and trade balance
        if import_dependency == "High" and trade_balance < 0:
            supply_risk = "High"
        elif import_dependency == "High" or (import_dependency == "Medium" and growth_trend == "decreasing"):
            supply_risk = "Medium"
        else:
            supply_risk = "Low"
        
    else:
        # Default values if no data
        import_dependency = "Low"
        key_sourcing_countries = []
        supply_risk = "Low"
        top_import_source = "N/A"
        trade_balance = 0
    
    # Generate feasibility summary using LLM
    context = {
        "import_dependency": import_dependency,
        "supply_risk": supply_risk,
        "sourcing_countries": key_sourcing_countries,
        "trade_balance": trade_balance
    }
    
    prompt = f"Provide a 2-3 line executive summary of supply-chain feasibility. " \
             f"Import dependency: {import_dependency}, Supply risk: {supply_risk}, " \
             f"Key sourcing: {', '.join(key_sourcing_countries) if key_sourcing_countries else 'N/A'}. " \
             f"Highlight supply-chain risks and opportunities."
    
    summary = call_llm(prompt, context)
    
    logger.info(f"EXIM Trade Agent: Analyzed trade feasibility - {import_dependency} dependency, {supply_risk} risk")
    
    # Calculate score based on supply resilience, manufacturability (0-100)
    score = 50  # Base score
    # Supply resilience factor (lower dependency = better)
    if import_dependency == "Low":
        score += 25
    elif import_dependency == "Medium":
        score += 10
    else:  # High dependency
        score -= 15
    # Manufacturability factor (lower risk = better)
    if supply_risk == "Low":
        score += 15
    elif supply_risk == "Medium":
        score += 5
    else:  # High risk
        score -= 20
    # Trade balance factor (positive = better)
    if trade_balance > 0:
        score += 10
    
    score = max(0, min(100, score))
    
    # Determine risk level
    if score >= 70:
        risk_level = "Low"
    elif score >= 40:
        risk_level = "Moderate"
    else:
        risk_level = "High"
    
    # Generate key signal based on context
    if import_dependency == "Low" and supply_risk == "Low":
        key_signal = f"Favorable supply chain with low import dependency and low supply risk enables reliable manufacturing"
    elif import_dependency == "Low":
        key_signal = f"Low import dependency supports supply resilience despite {supply_risk.lower()} supply risk"
    elif supply_risk == "Low":
        key_signal = f"Low supply risk mitigates {import_dependency.lower()} import dependency concerns"
    else:
        key_signal = f"{import_dependency} import dependency with {supply_risk.lower()} supply risk creates manufacturing constraints"
    
    # Generate justification
    justification_parts = []
    if import_dependency == "Low":
        justification_parts.append("Low import dependency reduces supply chain vulnerability")
    elif import_dependency == "High":
        justification_parts.append(f"High import dependency ({import_ratio:.0f}%) increases supply chain risk")
    if supply_risk == "Low":
        justification_parts.append("Low supply risk supports manufacturing feasibility")
    elif supply_risk == "High":
        justification_parts.append("High supply risk constrains production reliability")
    if trade_balance > 0:
        justification_parts.append(f"Positive trade balance supports supply resilience")
    elif trade_balance < 0:
        justification_parts.append(f"Negative trade balance indicates supply dependency")
    if key_sourcing_countries:
        justification_parts.append(f"Key sourcing from {', '.join(key_sourcing_countries[:2])} enables supply diversification")
    
    justification = ". ".join(justification_parts) if justification_parts else f"Supply chain analysis indicates {risk_level.lower()} manufacturing risk"
    
    # Calculate intent_relevance based on question intent
    question_intent = payload.get("question_intent", "TIME_TO_MARKET_OPTIMIZATION")
    intent_relevance = 0.5  # Default moderate
    
    if question_intent == "TIME_TO_MARKET_OPTIMIZATION":
        intent_relevance = 0.6  # Moderate-high relevance (supply affects timeline)
    elif question_intent == "REPURPOSING_FEASIBILITY":
        intent_relevance = 0.4  # Moderate relevance
    elif question_intent == "COMMERCIAL_VALUE_MAXIMIZATION":
        intent_relevance = 0.3  # Lower relevance
    else:
        intent_relevance = 0.2  # Low relevance for other intents
    
    # Generate blocking_issue
    blocking_issue = ""
    if risk_level == "High" or score < 40:
        if import_dependency > 0.7:
            blocking_issue = f"High import dependency ({import_dependency*100:.0f}%) creates supply chain vulnerability"
        elif supply_risk == "High":
            blocking_issue = f"High supply risk constrains manufacturing feasibility"
        else:
            blocking_issue = f"Supply chain risk profile ({risk_level}) constrains manufacturability"
    
    # Generate confidence_note
    if score >= 70:
        confidence_note = f"High confidence in supply chain (score: {score}/100) with diversified sourcing"
    elif score >= 50:
        confidence_note = f"Moderate confidence in supply chain (score: {score}/100) with manageable import dependency"
    else:
        confidence_note = f"Low confidence in supply chain (score: {score}/100) requires supply chain strategy"
    
    return {
        "agent": "exim",
        "summary": summary,
        "table": {
            "import_dependency": import_dependency,
            "top_exporting_countries": key_sourcing_countries
        },
        "details": {
            "supply_risk": supply_risk
        },
        "score": score,
        "risk_level": risk_level,
        "confidence_weight": 0.05,
        "intent_relevance": intent_relevance,
        "key_signal": key_signal,
        "blocking_issue": blocking_issue,
        "confidence_note": confidence_note,
        "justification": justification
    }


# Worker agent ready for EY Techathon demo.

