"""
Internal Knowledge Agent – surfaces enterprise insights from internal documents.
"""

import os
from typing import Dict, Any, List
import logging

from llm.llm_client import call_llm
from vector_store.vector_store import semantic_search, index_documents

logger = logging.getLogger(__name__)

# Track if internal documents have been indexed
_internal_docs_indexed = False


def _load_and_index_internal_documents() -> None:
    """Load internal documents from mock_data/internal_docs and index them into vector store."""
    global _internal_docs_indexed
    
    if _internal_docs_indexed:
        return
    
    internal_docs_path = os.path.join(os.path.dirname(__file__), "..", "mock_data", "internal_docs")
    documents = []
    
    if not os.path.exists(internal_docs_path):
        logger.warning(f"Internal docs directory not found: {internal_docs_path}")
        return
    
    # Load text files
    for filename in os.listdir(internal_docs_path):
        if filename.endswith(('.txt', '.pdf')):
            file_path = os.path.join(internal_docs_path, filename)
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()
                    documents.append({
                        "id": f"internal_{filename}",
                        "text": content,
                        "source": filename
                    })
            except Exception as e:
                logger.warning(f"Error reading {filename}: {str(e)}")
    
    # Index documents
    if documents:
        index_documents(documents)
        _internal_docs_indexed = True
        logger.info(f"Indexed {len(documents)} internal documents into vector store")


def analyze_internal(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Analyze internal knowledge base using semantic search.
    
    Surfaces enterprise insights from internal documents, reports, and knowledge bases.
    
    Args:
        payload: Request payload with query, molecule, therapeutic_area
        
    Returns:
        Analysis results with summary, key_points, and source_docs
    """
    logger.info("Internal Knowledge Agent: Starting enterprise knowledge retrieval")
    
    # Load and index internal documents (if not already indexed)
    _load_and_index_internal_documents()
    
    # Build search query
    query = payload.get("query", "").strip()
    molecule = payload.get("molecule", "").strip()
    
    search_query = f"{query} {molecule}".strip()
    if not search_query:
        search_query = "pharmaceutical strategy"
    
    # Perform semantic search
    search_results = semantic_search(search_query, top_k=3)
    
    # Extract key points from search results
    key_points = []
    source_docs = []
    
    for result in search_results:
        source_doc = result.get("source", "Unknown")
        source_docs.append(source_doc)
        
        # Extract first sentence or key phrase from text as bullet point
        text = result.get("text", "")
        if text:
            # Take first sentence or first 100 chars
            first_sentence = text.split('.')[0] if '.' in text else text[:100]
            if first_sentence.strip():
                key_points.append(first_sentence.strip() + ("..." if len(first_sentence) > 100 else ""))
    
    # Limit key points to top 3
    key_points = key_points[:3]
    
    # If no results, provide defaults
    if not search_results:
        key_points = ["No specific internal documents found matching the query."]
        source_docs = []
    
    # Generate internal strategy summary using LLM
    context = {
        "query": query,
        "molecule": molecule,
        "key_points": key_points,
        "source_docs": source_docs
    }
    
    prompt = f"Provide a 2-3 line executive summary of internal strategy relevance for {molecule or 'the query'}. " \
             f"Based on internal knowledge base findings, highlight strategic insights and corporate context."
    
    summary = call_llm(prompt, context)
    
    logger.info(f"Internal Knowledge Agent: Retrieved insights from {len(source_docs)} internal documents")
    
    # Calculate score based on strategic fit, capability alignment (0-100)
    score = 50  # Base score
    
    # Question-conditioned scoring adjustments
    query_lower = (payload.get("query", "") or payload.get("question", "")).lower()
    molecule = payload.get("molecule", "").lower()
    is_strategic_question = any(word in query_lower for word in ["strategy", "strategic", "portfolio", "capability", "alignment", "fit"])
    
    # Strategic fit factor (more relevant docs = better fit)
    if len(source_docs) >= 2:
        score += 20
    elif len(source_docs) >= 1:
        score += 10
    
    # Strategic questions: internal alignment is more critical
    if is_strategic_question:
        if len(source_docs) >= 2 and len(key_points) >= 3:
            score += 10  # Bonus for strategic questions with strong alignment
        elif len(source_docs) == 0:
            score -= 10  # Penalty for strategic questions with no internal context
    
    # Capability alignment proxy (key points indicate alignment)
    if len(key_points) >= 3:
        score += 15
    elif len(key_points) >= 1:
        score += 10
    
    # Check summary for strategic keywords
    summary_lower = summary.lower() if isinstance(summary, str) else ""
    if "strategic" in summary_lower or "alignment" in summary_lower or "fit" in summary_lower:
        score += 5
    
    score = max(0, min(100, score))
    
    # Determine risk level
    if score >= 70:
        risk_level = "Low"
    elif score >= 40:
        risk_level = "Moderate"
    else:
        risk_level = "High"
    
    # Generate key signal based on context
    if len(source_docs) >= 2 and len(key_points) >= 3:
        key_signal = f"Strong internal strategic alignment with {len(source_docs)} relevant documents and {len(key_points)} strategic insights"
    elif len(key_points) >= 2:
        key_signal = f"Moderate strategic fit with {len(key_points)} relevant insights from internal knowledge base"
    elif len(source_docs) >= 1:
        key_signal = f"Limited strategic alignment with {len(source_docs)} internal document(s) suggests capability gaps"
    else:
        key_signal = "Minimal internal strategic context requires external capability assessment"
    
    # Generate justification
    justification_parts = []
    if len(source_docs) >= 2:
        justification_parts.append(f"Multiple relevant documents ({len(source_docs)}) indicate strategic relevance")
    elif len(source_docs) >= 1:
        justification_parts.append(f"Internal documents ({len(source_docs)}) provide strategic context")
    if len(key_points) >= 3:
        justification_parts.append(f"Multiple strategic insights ({len(key_points)}) demonstrate capability alignment")
    elif len(key_points) >= 1:
        justification_parts.append(f"Strategic insights ({len(key_points)}) suggest partial alignment")
    if source_docs:
        doc_names = [doc.split('/')[-1] if '/' in doc else doc for doc in source_docs[:2]]
        justification_parts.append(f"Relevant documents: {', '.join(doc_names)}")
    
    justification = ". ".join(justification_parts) if justification_parts else f"Internal knowledge analysis indicates {risk_level.lower()} strategic fit"
    
    # Calculate intent_relevance based on question intent
    question_intent = payload.get("question_intent", "PORTFOLIO_PRIORITIZATION")
    intent_relevance = 0.6  # Default moderate
    
    if question_intent == "PORTFOLIO_PRIORITIZATION":
        intent_relevance = 0.8  # High relevance (strategic fit matters)
    elif question_intent == "REPURPOSING_FEASIBILITY":
        intent_relevance = 0.5  # Moderate relevance
    elif question_intent == "COMMERCIAL_VALUE_MAXIMIZATION":
        intent_relevance = 0.4  # Lower relevance
    elif question_intent == "CLINICAL_SUCCESS_PROBABILITY":
        intent_relevance = 0.3  # Low relevance
    elif question_intent == "MARKET_ACCESS_RISK":
        intent_relevance = 0.3  # Low relevance
    elif question_intent == "IP_OR_EXCLUSIVITY_RISK":
        intent_relevance = 0.2  # Low relevance
    elif question_intent == "TIME_TO_MARKET_OPTIMIZATION":
        intent_relevance = 0.3  # Low relevance
    
    # Generate blocking_issue
    blocking_issue = ""
    if risk_level == "High" or score < 40:
        if len(source_docs) == 0:
            blocking_issue = f"Lack of internal strategic context constrains alignment assessment"
        elif len(key_points) < 2:
            blocking_issue = f"Limited strategic insights ({len(key_points)}) indicate weak capability alignment"
        else:
            blocking_issue = f"Strategic fit risk ({risk_level}) constrains portfolio alignment"
    
    # Generate confidence_note
    if score >= 70:
        confidence_note = f"High confidence in strategic fit (score: {score}/100) with {len(source_docs)} relevant documents"
    elif score >= 50:
        confidence_note = f"Moderate confidence in strategic fit (score: {score}/100) with {len(key_points)} strategic insights"
    else:
        confidence_note = f"Low confidence in strategic fit (score: {score}/100) requires capability assessment"
    
    return {
        "agent": "internal",
        "summary": summary,
        "key_points": key_points,
        "source_docs": source_docs,
        "score": score,
        "risk_level": risk_level,
        "confidence_weight": 0.05,
        "intent_relevance": intent_relevance,
        "key_signal": key_signal,
        "blocking_issue": blocking_issue,
        "confidence_note": confidence_note,
        "justification": justification
    }


# Internal Knowledge Agent ready for EY Techathon demo.

