"""
IQVIA Insights Agent – analyzes market attractiveness and competition.
"""

import json
import os
from typing import Dict, Any, List
import logging

from llm.llm_client import call_llm

logger = logging.getLogger(__name__)


def analyze_iqvia(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Analyze market intelligence data from IQVIA mock data.
    
    Filters data by therapeutic_area and molecule, derives market metrics,
    and generates executive-style summary.
    
    Args:
        payload: Request payload with query, molecule, therapeutic_area
        
    Returns:
        Structured analysis with summary, table (market_size_usd, cagr_percent, 
        competition_level), and details (therapy_area, key_players)
    """
    logger.info("IQVIA Insights Agent: Starting market analysis")
    
    # Load mock data
    mock_data_path = os.path.join(os.path.dirname(__file__), "..", "mock_data", "iqvia.json")
    
    with open(mock_data_path, "r") as f:
        iqvia_data = json.load(f)
    
    # Filter data based on query parameters
    molecule = payload.get("molecule", "").strip()
    therapeutic_area = payload.get("therapeutic_area", "").strip()
    
    filtered_data = iqvia_data
    
    # Filter by therapeutic_area (primary filter)
    if therapeutic_area:
        therapeutic_area_lower = therapeutic_area.lower()
        filtered_data = [
            d for d in filtered_data 
            if therapeutic_area_lower in d.get("therapeutic_area", "").lower()
        ]
    
    # Further filter by molecule if provided
    if molecule and filtered_data:
        molecule_lower = molecule.lower()
        molecule_filtered = [
            d for d in filtered_data 
            if molecule_lower in d.get("molecule", "").lower()
        ]
        if molecule_filtered:
            filtered_data = molecule_filtered
    
    # If no matches, use first entry as default
    if not filtered_data:
        filtered_data = iqvia_data[:1] if iqvia_data else []
    
    # Derive market metrics from filtered data
    if filtered_data:
        # Use the first matching record (or aggregate if multiple)
        primary_record = filtered_data[0]
        
        market_size_usd = primary_record.get("market_size_usd_millions", 0)
        growth_rate = primary_record.get("growth_rate_percent", 0)
        
        # Determine competition level based on market share concentration
        market_share_leader = primary_record.get("market_share_percent", 0)
        key_players_count = len(primary_record.get("key_players", []))
        
        if market_share_leader > 50 or key_players_count <= 2:
            competition_level = "High"
        elif market_share_leader > 30 or key_players_count <= 4:
            competition_level = "Medium"
        else:
            competition_level = "Low"
        
        therapy_area = primary_record.get("therapeutic_area", therapeutic_area or "N/A")
        key_players = primary_record.get("key_players", [])
    else:
        # Default values if no data
        market_size_usd = 0
        growth_rate = 0
        competition_level = "Low"
        therapy_area = therapeutic_area or "N/A"
        key_players = []
    
    # Generate executive-style summary using LLM
    context = {
        "market_size": market_size_usd,
        "growth_rate": growth_rate,
        "competition_level": competition_level,
        "therapy_area": therapy_area,
        "key_players": key_players
    }
    
    prompt = f"Provide a 2-3 line executive summary of market attractiveness for {therapy_area}. " \
             f"Market size: ${market_size_usd}M, Growth rate: {growth_rate}%, " \
             f"Competition: {competition_level}. Highlight key market dynamics and opportunities."
    
    summary = call_llm(prompt, context)
    
    logger.info(f"IQVIA Insights Agent: Analyzed {therapy_area} market")
    
    # Calculate score based on demand, competition, pricing power (0-100)
    score = 50  # Base score
    
    # Question-conditioned scoring adjustments
    query_lower = (payload.get("query", "") or payload.get("question", "")).lower()
    is_market_access = any(word in query_lower for word in ["market access", "payer", "reimbursement", "commercial", "pricing"])
    is_repurposing = any(word in query_lower for word in ["repurpose", "reposition", "existing drug"])
    
    # Market size factor (demand indicator)
    if market_size_usd >= 1000:
        score += 20
    elif market_size_usd >= 500:
        score += 15
    elif market_size_usd >= 100:
        score += 10
    elif market_size_usd > 0:
        score += 5
    
    # Market access questions: competition is more critical
    if is_market_access:
        if competition_level == "Low":
            score += 20  # Bonus for market access questions
        elif competition_level == "High":
            score -= 15  # Penalty for market access questions
    else:
        # Standard competition factor
        if competition_level == "Low":
            score += 15
        elif competition_level == "Medium":
            score += 5
        else:  # High competition
            score -= 10
    
    # Growth rate factor (demand trend)
    if growth_rate >= 10:
        score += 15
    elif growth_rate >= 5:
        score += 10
    elif growth_rate > 0:
        score += 5
    
    # Repurposing questions: market size matters more (proven market)
    if is_repurposing and market_size_usd >= 500:
        score += 10
    
    score = max(0, min(100, score))
    
    # Determine risk level
    if score >= 70:
        risk_level = "Low"
    elif score >= 40:
        risk_level = "Moderate"
    else:
        risk_level = "High"
    
    # Generate key signal based on context
    query_lower = (payload.get("query", "") or payload.get("question", "")).lower()
    if market_size_usd >= 1000 and growth_rate >= 10:
        key_signal = f"Large addressable market ({market_size_usd}M) with strong growth trajectory ({growth_rate}% CAGR) indicates high commercial viability"
    elif competition_level == "Low" and market_size_usd >= 500:
        key_signal = f"Favorable competitive landscape with {competition_level.lower()} competition and ${market_size_usd}M market size"
    elif growth_rate >= 10:
        key_signal = f"Strong market growth ({growth_rate}% CAGR) signals expanding opportunity despite competition"
    else:
        key_signal = f"Market size ${market_size_usd}M with {competition_level.lower()} competition requires careful positioning"
    
    # Generate justification
    justification_parts = []
    if market_size_usd >= 1000:
        justification_parts.append(f"Large market size (${market_size_usd}M) demonstrates significant demand potential")
    elif market_size_usd >= 500:
        justification_parts.append(f"Moderate market size (${market_size_usd}M) indicates viable commercial opportunity")
    if growth_rate >= 10:
        justification_parts.append(f"Strong growth rate ({growth_rate}% CAGR) suggests expanding market dynamics")
    elif growth_rate >= 5:
        justification_parts.append(f"Moderate growth ({growth_rate}% CAGR) indicates stable market expansion")
    if competition_level == "Low":
        justification_parts.append(f"Low competition enables pricing power and market share capture")
    elif competition_level == "High":
        justification_parts.append(f"High competition constrains pricing power and requires differentiation")
    
    justification = ". ".join(justification_parts) if justification_parts else f"Market analysis for {therapy_area} indicates {risk_level.lower()} commercial attractiveness"
    
    # Calculate intent_relevance based on question intent
    question_intent = payload.get("question_intent", "COMMERCIAL_VALUE_MAXIMIZATION")
    intent_relevance = 1.0  # Default
    
    if question_intent == "COMMERCIAL_VALUE_MAXIMIZATION":
        intent_relevance = 1.0  # Maximum relevance
    elif question_intent == "MARKET_ACCESS_RISK":
        intent_relevance = 0.9  # High relevance (payer dynamics)
    elif question_intent == "PORTFOLIO_PRIORITIZATION":
        intent_relevance = 0.8  # High relevance (opportunity cost)
    elif question_intent == "REPURPOSING_FEASIBILITY":
        intent_relevance = 0.5  # Moderate relevance (proven market matters)
    elif question_intent == "CLINICAL_SUCCESS_PROBABILITY":
        intent_relevance = 0.4  # Lower relevance
    elif question_intent == "IP_OR_EXCLUSIVITY_RISK":
        intent_relevance = 0.3  # Low relevance
    elif question_intent == "TIME_TO_MARKET_OPTIMIZATION":
        intent_relevance = 0.4  # Lower relevance
    
    # Generate blocking_issue
    blocking_issue = ""
    if risk_level == "High" or score < 40:
        if competition_level == "High":
            blocking_issue = f"High competition level constrains pricing power and market share capture"
        elif market_size_usd < 100:
            blocking_issue = f"Limited market size (${market_size_usd}M) constrains commercial viability"
        elif growth_rate < 0:
            blocking_issue = f"Negative growth rate ({growth_rate}%) indicates declining market opportunity"
        else:
            blocking_issue = f"Commercial risk profile ({risk_level}) constrains revenue potential"
    
    # Generate confidence_note
    if score >= 70:
        confidence_note = f"High confidence in commercial attractiveness (score: {score}/100) based on ${market_size_usd}M market and {growth_rate}% growth"
    elif score >= 50:
        confidence_note = f"Moderate confidence in commercial attractiveness (score: {score}/100) with {competition_level.lower()} competition"
    else:
        confidence_note = f"Low confidence in commercial attractiveness (score: {score}/100) requires market validation"
    
    return {
        "agent": "commercial",
        "summary": summary,
        "table": {
            "market_size_usd": f"${market_size_usd}M",
            "cagr_percent": f"{growth_rate}%",
            "competition_level": competition_level
        },
        "details": {
            "therapy_area": therapy_area,
            "key_players": key_players
        },
        "score": score,
        "risk_level": risk_level,
        "confidence_weight": 0.20,
        "intent_relevance": intent_relevance,
        "key_signal": key_signal,
        "blocking_issue": blocking_issue,
        "confidence_note": confidence_note,
        "justification": justification
    }


# Worker agent ready for EY Techathon demo.

