"""
Patent Landscape Agent – evaluates IP exposure and freedom-to-operate risk.
"""

import json
import os
from typing import Dict, Any, List
from datetime import datetime
import logging

from llm.llm_client import call_llm

logger = logging.getLogger(__name__)


def analyze_patent(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Analyze patent landscape data to evaluate IP exposure and freedom-to-operate risk.
    
    Filters patents by molecule and therapeutic_area, counts active and expired patents,
    and assesses patent risk level.
    
    Args:
        payload: Request payload with query, molecule, therapeutic_area
        
    Returns:
        Structured analysis with summary, table (active_patents, expired_patents, 
        patent_risk), and details (notable_patents)
    """
    logger.info("Patent Landscape Agent: Starting IP analysis")
    
    # Load mock data
    mock_data_path = os.path.join(os.path.dirname(__file__), "..", "mock_data", "patents.json")
    
    with open(mock_data_path, "r") as f:
        patent_data = json.load(f)
    
    # Filter data based on query parameters
    molecule = payload.get("molecule", "").strip()
    therapeutic_area = payload.get("therapeutic_area", "").strip()
    
    filtered_data = patent_data
    
    # Filter by therapeutic_area (primary filter)
    if therapeutic_area:
        therapeutic_area_lower = therapeutic_area.lower()
        filtered_data = [
            d for d in filtered_data 
            if therapeutic_area_lower in d.get("category", "").lower()
        ]
    
    # Further filter by molecule if provided
    if molecule and filtered_data:
        molecule_lower = molecule.lower()
        molecule_filtered = [
            d for d in filtered_data 
            if molecule_lower in d.get("title", "").lower() or 
               molecule_lower in d.get("inventor", "").lower()
        ]
        if molecule_filtered:
            filtered_data = molecule_filtered
    
    # If no matches, use all data as default
    if not filtered_data:
        filtered_data = patent_data
    
    # Analyze patent data
    active_patents = 0
    expired_patents = 0
    notable_patents = []
    current_date = datetime.now()
    total_patents = 0
    
    for patent in filtered_data:
        total_patents += 1
        status = patent.get("status", "").lower()
        expiration_date_str = patent.get("expiration_date", "")
        
        # Check if patent is active based on status
        if status == "active":
            active_patents += 1
        else:
            expired_patents += 1
        
        # Also check expiration date if available
        if expiration_date_str:
            try:
                exp_date = datetime.strptime(expiration_date_str, "%Y-%m-%d")
                if exp_date < current_date and status == "active":
                    # Patent expired but status not updated
                    expired_patents += 1
                    active_patents = max(0, active_patents - 1)
            except (ValueError, TypeError):
                pass
        
        # Collect notable patent information
        notable_patents.append({
            "patent_number": patent.get("patent_number", "N/A"),
            "title": patent.get("title", "N/A"),
            "status": patent.get("status", "N/A"),
            "expiration_date": patent.get("expiration_date", "N/A")
        })
    
    # Determine patent risk
    patent_risk = "High" if active_patents > 0 else "Low"
    
    # Generate IP-risk summary using LLM
    context = {
        "active_patents": active_patents,
        "expired_patents": expired_patents,
        "patent_risk": patent_risk,
        "notable_patents": notable_patents[:3]  # Top 3 for context
    }
    
    prompt = f"Provide a 2-3 line executive summary of IP exposure and freedom-to-operate risk. " \
             f"Active patents: {active_patents}, Expired: {expired_patents}, " \
             f"Risk level: {patent_risk}. Highlight key IP considerations and FTO implications."
    
    summary = call_llm(prompt, context)
    
    logger.info(f"Patent Landscape Agent: Analyzed {len(filtered_data)} patents - {active_patents} active, {expired_patents} expired")
    
    # Calculate score based on FTO, expiry window, blocking risk (0-100)
    score = 50  # Base score
    # FTO factor (fewer active patents = better FTO)
    total_patents = active_patents + expired_patents
    if total_patents > 0:
        expired_ratio = expired_patents / total_patents
        score += int(expired_ratio * 30)  # More expired = better FTO
    # Blocking risk factor
    if patent_risk == "Low":
        score += 20
    elif patent_risk == "High":
        score -= 30
    # Expiry window factor (more expired = larger window)
    if expired_patents >= 5:
        score += 10
    
    # Question-conditioned scoring adjustments
    query_lower = (payload.get("query", "") or payload.get("question", "")).lower()
    molecule = payload.get("molecule", "").lower()
    
    # Adjust for question context
    if "ip" in query_lower or "patent" in query_lower or "freedom" in query_lower:
        # IP-focused questions get more weight on patent data
        if active_patents == 0:
            score += 10  # Bonus for clear FTO
        elif active_patents > 5:
            score -= 15  # Penalty for crowded IP space
    if "repurpose" in query_lower or "reposition" in query_lower:
        # Repurposing questions: expired patents are more valuable
        if expired_patents >= 3:
            score += 5
    if "novel" in query_lower or "first-in-class" in query_lower:
        # Novel drugs need strong FTO
        if active_patents > 2:
            score -= 10
    
    score = max(0, min(100, score))
    
    # Determine risk level (inverted: higher score = lower risk)
    if score >= 70:
        risk_level = "Low"
    elif score >= 40:
        risk_level = "Moderate"
    else:
        risk_level = "High"
    
    # Generate key signal based on context
    if active_patents == 0 and expired_patents > 0:
        key_signal = f"Clear freedom-to-operate with {expired_patents} expired patents and no active blocking IP"
    elif active_patents <= 2 and expired_ratio > 0.6:
        key_signal = f"Favorable IP landscape with {active_patents} active patents and {expired_patents} expired, enabling development pathway"
    elif active_patents > 5:
        key_signal = f"Crowded IP space with {active_patents} active patents creates blocking risk requiring careful navigation"
    else:
        key_signal = f"Moderate IP landscape with {active_patents} active and {expired_patents} expired patents requires FTO diligence"
    
    # Generate justification
    justification_parts = []
    if expired_ratio > 0.6:
        justification_parts.append(f"High expired patent ratio ({int(expired_ratio*100)}%) indicates favorable FTO window")
    elif expired_ratio > 0.4:
        justification_parts.append(f"Moderate expired patent ratio ({int(expired_ratio*100)}%) provides some FTO opportunity")
    if active_patents == 0:
        justification_parts.append("No active blocking patents enable clear development pathway")
    elif active_patents <= 2:
        justification_parts.append(f"Limited active patents ({active_patents}) suggest manageable IP risk")
    else:
        justification_parts.append(f"Multiple active patents ({active_patents}) require IP strategy and FTO analysis")
    if patent_risk == "Low":
        justification_parts.append("Low patent risk level supports portfolio advancement")
    elif patent_risk == "High":
        justification_parts.append("High patent risk level requires IP mitigation strategy")
    
    justification = ". ".join(justification_parts) if justification_parts else f"IP landscape analysis shows {risk_level.lower()} risk with {active_patents} active and {expired_patents} expired patents"
    
    # Calculate intent_relevance based on question intent
    question_intent = payload.get("question_intent", "IP_OR_EXCLUSIVITY_RISK")
    intent_relevance = 1.0  # Default
    
    if question_intent == "IP_OR_EXCLUSIVITY_RISK":
        intent_relevance = 1.0  # Maximum relevance
    elif question_intent == "REPURPOSING_FEASIBILITY":
        intent_relevance = 0.7  # High relevance (expired patents valuable)
    elif question_intent == "TIME_TO_MARKET_OPTIMIZATION":
        intent_relevance = 0.6  # Moderate relevance (IP clearance affects timeline)
    elif question_intent == "COMMERCIAL_VALUE_MAXIMIZATION":
        intent_relevance = 0.5  # Moderate relevance
    elif question_intent == "CLINICAL_SUCCESS_PROBABILITY":
        intent_relevance = 0.3  # Low relevance
    elif question_intent == "MARKET_ACCESS_RISK":
        intent_relevance = 0.3  # Low relevance
    elif question_intent == "PORTFOLIO_PRIORITIZATION":
        intent_relevance = 0.4  # Lower relevance
    
    # Generate blocking_issue
    blocking_issue = ""
    if risk_level == "High" or score < 40:
        if active_patents > 5:
            blocking_issue = f"High active patent count ({active_patents}) creates blocking IP risk"
        elif patent_risk == "High":
            blocking_issue = f"High patent risk constrains freedom-to-operate"
        elif expired_ratio < 0.3:
            blocking_issue = f"Limited expired patents ({expired_patents}) restricts FTO window"
        else:
            blocking_issue = f"IP risk profile ({risk_level}) constrains development pathway"
    
    # Generate confidence_note
    if score >= 70:
        confidence_note = f"High confidence in IP landscape (score: {score}/100) with {expired_patents} expired patents enabling FTO"
    elif score >= 50:
        confidence_note = f"Moderate confidence in IP landscape (score: {score}/100) with {active_patents} active patents requiring diligence"
    else:
        confidence_note = f"Low confidence in IP landscape (score: {score}/100) requires IP strategy refinement"
    
    return {
        "agent": "patent",
        "summary": summary,
        "table": {
            "active_patents": active_patents,
            "expired_patents": expired_patents,
            "patent_risk": patent_risk
        },
        "details": {
            "notable_patents": notable_patents
        },
        "score": score,
        "risk_level": risk_level,
        "confidence_weight": 0.20,
        "intent_relevance": intent_relevance,
        "key_signal": key_signal,
        "blocking_issue": blocking_issue,
        "confidence_note": confidence_note,
        "justification": justification
    }


# Patent Landscape Agent ready for EY Techathon demo.

