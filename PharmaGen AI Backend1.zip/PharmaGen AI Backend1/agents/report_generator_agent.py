"""
Report Generator Agent – produces executive-ready innovation reports.
"""

import os
from typing import Dict, Any
from datetime import datetime
import logging

from llm.llm_client import call_llm

logger = logging.getLogger(__name__)


def generate_report(decision: Dict[str, Any], agent_outputs: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate an executive-ready innovation report from agent outputs and decision.
    
    Creates a structured report with all key sections suitable for EY demo and presentations.
    
    Args:
        decision: Decision dictionary with "decision" (VIABLE/NOT_VIABLE) and "reasoning"
        agent_outputs: Dictionary with keys: market, trade, patent, clinical, scientific, internal
        
    Returns:
        Dictionary with "report_path" and "report_status"
    """
    logger.info("Report Generator Agent: Generating executive report")
    
    # Create report output directory if it doesn't exist
    report_dir = os.path.join(os.path.dirname(__file__), "..", "report_output")
    os.makedirs(report_dir, exist_ok=True)
    
    # Generate timestamp for filename
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_filename = f"pharmagen_report_{timestamp}"
    report_path = os.path.join(report_dir, f"{report_filename}.txt")
    
    # Generate report content
    report_content = _build_report_content(decision, agent_outputs)
    
    # Save report to file
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report_content)
    
    logger.info(f"Report Generator Agent: Generated report at {report_path}")
    
    return {
        "report_path": report_path,
        "report_status": "generated"
    }


def _build_report_content(decision: Dict[str, Any], agent_outputs: Dict[str, Any]) -> str:
    """Build the complete report content with all sections."""
    
    decision_status = decision.get("decision", "NOT_VIABLE")
    decision_reasoning = decision.get("reasoning", "")
    
    # Extract agent outputs
    market_data = agent_outputs.get("market", {})
    trade_data = agent_outputs.get("trade", {})
    patent_data = agent_outputs.get("patent", {})
    clinical_data = agent_outputs.get("clinical", {})
    scientific_data = agent_outputs.get("scientific", {})
    internal_data = agent_outputs.get("internal", {})
    
    # Build report sections
    sections = []
    
    # Header
    sections.append("=" * 80)
    sections.append("PHARMAGEN AI - INNOVATION PORTFOLIO REPORT")
    sections.append("=" * 80)
    sections.append("")
    sections.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    sections.append("")
    
    # Executive Summary
    sections.append("EXECUTIVE SUMMARY")
    sections.append("-" * 80)
    sections.append("")
    executive_summary = _generate_executive_summary(decision_status, decision_reasoning, agent_outputs)
    sections.append(executive_summary)
    sections.append("")
    
    # Market Attractiveness (IQVIA)
    sections.append("MARKET ATTRACTIVENESS")
    sections.append("-" * 80)
    sections.append("")
    market_section = _format_market_section(market_data)
    sections.append(market_section)
    sections.append("")
    
    # Supply & Trade Feasibility (EXIM)
    sections.append("SUPPLY & TRADE FEASIBILITY")
    sections.append("-" * 80)
    sections.append("")
    trade_section = _format_trade_section(trade_data)
    sections.append(trade_section)
    sections.append("")
    
    # Patent & IP Risk
    sections.append("PATENT & IP RISK")
    sections.append("-" * 80)
    sections.append("")
    patent_section = _format_patent_section(patent_data)
    sections.append(patent_section)
    sections.append("")
    
    # Clinical Pipeline Overview
    sections.append("CLINICAL PIPELINE OVERVIEW")
    sections.append("-" * 80)
    sections.append("")
    clinical_section = _format_clinical_section(clinical_data)
    sections.append(clinical_section)
    sections.append("")
    
    # Scientific Evidence
    sections.append("SCIENTIFIC EVIDENCE")
    sections.append("-" * 80)
    sections.append("")
    scientific_section = _format_scientific_section(scientific_data)
    sections.append(scientific_section)
    sections.append("")
    
    # Internal Strategic Alignment
    sections.append("INTERNAL STRATEGIC ALIGNMENT")
    sections.append("-" * 80)
    sections.append("")
    internal_section = _format_internal_section(internal_data)
    sections.append(internal_section)
    sections.append("")
    
    # Final Recommendation
    sections.append("FINAL RECOMMENDATION")
    sections.append("-" * 80)
    sections.append("")
    recommendation = _generate_recommendation(decision_status, decision_reasoning, agent_outputs)
    sections.append(recommendation)
    sections.append("")
    
    # Footer
    sections.append("=" * 80)
    sections.append("END OF REPORT")
    sections.append("=" * 80)
    
    return "\n".join(sections)


def _generate_executive_summary(decision_status: str, decision_reasoning: str, agent_outputs: Dict[str, Any]) -> str:
    """Generate executive summary based on decision status."""
    
    if decision_status == "VIABLE":
        base_text = f"This analysis identifies a VIABLE innovation opportunity with strong potential for portfolio development. {decision_reasoning} The comprehensive assessment across market attractiveness, supply chain feasibility, IP landscape, clinical pipeline, and scientific evidence supports strategic investment consideration."
    else:
        base_text = f"This analysis indicates the opportunity is NOT VIABLE for portfolio development at this time. {decision_reasoning} Key risk factors and market constraints have been identified that limit the strategic value of this opportunity."
    
    # Polish language using LLM (light touch)
    context = {"base_text": base_text, "decision_status": decision_status}
    prompt = f"Polish this executive summary for a business audience. Keep it concise (2-3 sentences) and professional. Base text: {base_text}"
    
    try:
        polished = call_llm(prompt, context)
        return polished
    except Exception:
        return base_text


def _format_market_section(market_data: Dict[str, Any]) -> str:
    """Format market attractiveness section from IQVIA agent output."""
    if not market_data:
        return "Market data not available."
    
    summary = market_data.get("summary", "Market analysis completed.")
    table = market_data.get("table", {})
    details = market_data.get("details", {})
    
    lines = []
    lines.append(summary)
    lines.append("")
    lines.append("Key Metrics:")
    lines.append(f"  • Market Size: {table.get('market_size_usd', 'N/A')}")
    lines.append(f"  • CAGR: {table.get('cagr_percent', 'N/A')}")
    lines.append(f"  • Competition Level: {table.get('competition_level', 'N/A')}")
    
    key_players = details.get("key_players", [])
    if key_players:
        lines.append(f"  • Key Players: {', '.join(key_players[:5])}")
    
    return "\n".join(lines)


def _format_trade_section(trade_data: Dict[str, Any]) -> str:
    """Format supply & trade feasibility section from EXIM agent output."""
    if not trade_data:
        return "Trade data not available."
    
    summary = trade_data.get("summary", "Trade analysis completed.")
    table = trade_data.get("table", {})
    details = trade_data.get("details", {})
    
    lines = []
    lines.append(summary)
    lines.append("")
    lines.append("Key Metrics:")
    lines.append(f"  • Import Dependency: {table.get('import_dependency', 'N/A')}")
    lines.append(f"  • Supply Risk: {details.get('supply_risk', 'N/A')}")
    
    sourcing_countries = table.get("top_exporting_countries", [])
    if sourcing_countries:
        lines.append(f"  • Key Sourcing Countries: {', '.join(sourcing_countries)}")
    
    return "\n".join(lines)


def _format_patent_section(patent_data: Dict[str, Any]) -> str:
    """Format patent & IP risk section from Patent agent output."""
    if not patent_data:
        return "Patent data not available."
    
    summary = patent_data.get("summary", "Patent analysis completed.")
    table = patent_data.get("table", {})
    details = patent_data.get("details", {})
    
    lines = []
    lines.append(summary)
    lines.append("")
    lines.append("Key Metrics:")
    lines.append(f"  • Active Patents: {table.get('active_patents', 0)}")
    lines.append(f"  • Expired Patents: {table.get('expired_patents', 0)}")
    lines.append(f"  • Patent Risk: {table.get('patent_risk', 'N/A')}")
    
    notable_patents = details.get("notable_patents", [])
    if notable_patents:
        lines.append("")
        lines.append("Notable Patents:")
        for patent in notable_patents[:3]:
            patent_num = patent.get("patent_number", "N/A")
            title = patent.get("title", "N/A")[:60] + "..." if len(patent.get("title", "")) > 60 else patent.get("title", "N/A")
            lines.append(f"  • {patent_num}: {title}")
    
    return "\n".join(lines)


def _format_clinical_section(clinical_data: Dict[str, Any]) -> str:
    """Format clinical pipeline overview section from Clinical agent output."""
    if not clinical_data:
        return "Clinical trial data not available."
    
    summary = clinical_data.get("summary", "Clinical analysis completed.")
    table = clinical_data.get("table", {})
    details = clinical_data.get("details", {})
    
    lines = []
    lines.append(summary)
    lines.append("")
    lines.append("Pipeline Overview:")
    lines.append(f"  • Phase I Trials: {table.get('phase_1', 0)}")
    lines.append(f"  • Phase II Trials: {table.get('phase_2', 0)}")
    lines.append(f"  • Phase III Trials: {table.get('phase_3', 0)}")
    lines.append(f"  • Clinical Saturation: {table.get('clinical_saturation', 'N/A')}")
    
    key_sponsors = details.get("key_sponsors", [])
    if key_sponsors:
        lines.append(f"  • Key Sponsors: {', '.join(key_sponsors[:5])}")
    
    return "\n".join(lines)


def _format_scientific_section(scientific_data: Dict[str, Any]) -> str:
    """Format scientific evidence section from Web Intelligence agent output."""
    if not scientific_data:
        return "Scientific evidence not available."
    
    summary = scientific_data.get("summary", "Scientific analysis completed.")
    evidence = scientific_data.get("evidence", [])
    confidence = scientific_data.get("confidence_level", "N/A")
    
    lines = []
    lines.append(summary)
    lines.append("")
    lines.append(f"Confidence Level: {confidence}")
    
    if evidence:
        lines.append("")
        lines.append("Key Evidence Sources:")
        for ev in evidence[:3]:
            source = ev.get("source", "Unknown")
            excerpt = ev.get("excerpt", "")[:100] + "..." if len(ev.get("excerpt", "")) > 100 else ev.get("excerpt", "")
            lines.append(f"  • {source}: {excerpt}")
    
    return "\n".join(lines)


def _format_internal_section(internal_data: Dict[str, Any]) -> str:
    """Format internal strategic alignment section from Internal agent output."""
    if not internal_data:
        return "Internal knowledge data not available."
    
    summary = internal_data.get("summary", "Internal analysis completed.")
    key_points = internal_data.get("key_points", [])
    source_docs = internal_data.get("source_docs", [])
    
    lines = []
    lines.append(summary)
    
    if key_points:
        lines.append("")
        lines.append("Key Strategic Points:")
        for point in key_points:
            lines.append(f"  • {point}")
    
    if source_docs:
        lines.append("")
        lines.append(f"Source Documents: {', '.join(source_docs)}")
    
    return "\n".join(lines)


def _generate_recommendation(decision_status: str, decision_reasoning: str, agent_outputs: Dict[str, Any]) -> str:
    """Generate final recommendation based on decision and all agent outputs."""
    
    if decision_status == "VIABLE":
        base_text = f"RECOMMENDATION: PROCEED with portfolio development. This opportunity demonstrates strong market potential, manageable supply chain risks, favorable IP landscape, and supportive clinical pipeline. Next steps should include detailed feasibility study, regulatory pathway assessment, and partnership evaluation."
    else:
        base_text = f"RECOMMENDATION: DO NOT PROCEED at this time. {decision_reasoning} Consider alternative therapeutic areas or revisit this opportunity after addressing identified risk factors."
    
    # Polish language using LLM (light touch)
    context = {"base_text": base_text, "decision_status": decision_status}
    prompt = f"Polish this recommendation for a business audience. Keep it clear and actionable (2-3 sentences). Base text: {base_text}"
    
    try:
        polished = call_llm(prompt, context)
        return polished
    except Exception:
        return base_text


# PharmaGen AI backend complete – EY Round 2 demo ready.

