"""
Web Intelligence Agent – retrieves scientific literature, guidelines, and real-world evidence.
"""

import json
import os
from typing import Dict, Any, List
import logging

from llm.llm_client import call_llm
from vector_store.vector_store import index_documents, semantic_search

logger = logging.getLogger(__name__)

# Track if web documents have been indexed
_web_docs_indexed = False


def _load_and_index_web_documents() -> None:
    """Load web documents from mock data and index them into vector store."""
    global _web_docs_indexed
    
    if _web_docs_indexed:
        return
    
    # Load mock data
    mock_data_path = os.path.join(os.path.dirname(__file__), "..", "mock_data", "web_results.json")
    
    with open(mock_data_path, "r") as f:
        web_data = json.load(f)
    
    # Convert to vector store format
    documents = []
    for idx, item in enumerate(web_data):
        # Combine title and content for searchable text
        text = f"{item.get('title', '')} {item.get('content', '')}"
        documents.append({
            "id": f"web_{idx}",
            "text": text,
            "source": item.get("source", "Unknown"),
            "metadata": item  # Store full item for later retrieval
        })
    
    # Index documents
    index_documents(documents)
    _web_docs_indexed = True
    logger.info(f"Indexed {len(documents)} web documents into vector store")


def analyze_web_intel(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Analyze web intelligence data using semantic search.
    
    Retrieves scientific literature, guidelines, and real-world evidence from
    indexed web documents using semantic search.
    
    Args:
        payload: Request payload with query, molecule, therapeutic_area
        
    Returns:
        Analysis results with summary, evidence, and confidence_level
    """
    logger.info("Web Intelligence Agent: Starting scientific evidence retrieval")
    
    # Load and index web documents (if not already indexed)
    _load_and_index_web_documents()
    
    # Build search query
    query = payload.get("query", "").strip()
    therapeutic_area = payload.get("therapeutic_area", "").strip()
    
    search_query = f"{query} {therapeutic_area}".strip()
    if not search_query:
        search_query = "pharmaceutical research"
    
    # Perform semantic search
    search_results = semantic_search(search_query, top_k=3)
    
    # Load original web data to get full content
    mock_data_path = os.path.join(os.path.dirname(__file__), "..", "mock_data", "web_results.json")
    with open(mock_data_path, "r") as f:
        web_data = json.load(f)
    
    # Build evidence list from search results
    evidence = []
    for result in search_results:
        # Find corresponding web data item
        source_name = result.get("source", "")
        matching_item = next(
            (item for item in web_data if item.get("source") == source_name),
            None
        )
        
        if matching_item:
            excerpt = matching_item.get("content", "")[:200] + "..." if len(matching_item.get("content", "")) > 200 else matching_item.get("content", "")
            evidence.append({
                "source": source_name,
                "excerpt": excerpt
            })
    
    # If no evidence found, use default entries
    if not evidence and web_data:
        for item in web_data[:2]:
            excerpt = item.get("content", "")[:200] + "..." if len(item.get("content", "")) > 200 else item.get("content", "")
            evidence.append({
                "source": item.get("source", "Unknown"),
                "excerpt": excerpt
            })
    
    # Determine confidence level based on number of results
    if len(search_results) >= 3:
        confidence_level = "High"
    elif len(search_results) >= 1:
        confidence_level = "Medium"
    else:
        confidence_level = "Low"
    
    # Generate scientific summary using LLM
    context = {
        "query": query,
        "therapeutic_area": therapeutic_area,
        "evidence": evidence
    }
    
    prompt = f"Provide a 2-3 line executive summary of scientific evidence and guidelines for {therapeutic_area or 'the query'}. " \
             f"Based on the retrieved evidence, highlight key scientific findings and clinical implications."
    
    summary = call_llm(prompt, context)
    
    logger.info(f"Web Intelligence Agent: Retrieved {len(evidence)} evidence sources with {confidence_level} confidence")
    
    # Calculate score based on unmet need signals, guidelines (0-100)
    score = 50  # Base score
    # Evidence strength factor
    if confidence_level == "High":
        score += 25
    elif confidence_level == "Medium":
        score += 10
    # Unmet need proxy (more evidence = stronger signal)
    if len(evidence) >= 3:
        score += 15
    elif len(evidence) >= 1:
        score += 5
    # Check summary for unmet need keywords
    summary_lower = summary.lower() if isinstance(summary, str) else ""
    if "unmet" in summary_lower or "limited" in summary_lower or "need" in summary_lower:
        score += 10
    
    score = max(0, min(100, score))
    
    # Determine risk level
    if score >= 70:
        risk_level = "Low"
    elif score >= 40:
        risk_level = "Moderate"
    else:
        risk_level = "High"
    
    # Generate key signal based on context
    query_lower = (payload.get("query", "") or payload.get("question", "")).lower()
    unmet_keywords = ["unmet", "limited options", "need", "gap"]
    unmet_need_signals = any(kw in query_lower for kw in unmet_keywords) or any(
        any(kw in str(item.get("content", "")).lower() for kw in unmet_keywords) for item in evidence[:2]
    )
    
    if confidence_level == "High" and len(evidence) >= 3:
        key_signal = f"Strong scientific evidence base ({len(evidence)} sources) with high confidence validates therapeutic rationale"
    elif unmet_need_signals and len(evidence) >= 2:
        key_signal = f"Evidence of unmet medical need supported by {len(evidence)} scientific sources suggests market opportunity"
    elif confidence_level == "High":
        key_signal = f"High confidence evidence validates development rationale despite limited sources"
    else:
        key_signal = f"Moderate evidence strength ({confidence_level.lower()} confidence, {len(evidence)} sources) requires further validation"
    
    # Generate justification
    justification_parts = []
    if confidence_level == "High":
        justification_parts.append(f"High confidence evidence supports scientific rationale")
    elif confidence_level == "Medium":
        justification_parts.append(f"Moderate confidence evidence provides credible foundation")
    if len(evidence) >= 3:
        justification_parts.append(f"Multiple evidence sources ({len(evidence)}) strengthen validation")
    if unmet_need_signals:
        justification_parts.append("Unmet need signals indicate market opportunity")
    if evidence:
        sources = [e.get("source", "Unknown") for e in evidence[:2]]
        justification_parts.append(f"Evidence from {', '.join(sources)} supports therapeutic approach")
    
    justification = ". ".join(justification_parts) if justification_parts else f"Scientific evidence analysis indicates {risk_level.lower()} validation risk"
    
    # Calculate intent_relevance based on question intent
    question_intent = payload.get("question_intent", "CLINICAL_SUCCESS_PROBABILITY")
    intent_relevance = 0.7  # Default moderate-high
    
    if question_intent == "CLINICAL_SUCCESS_PROBABILITY":
        intent_relevance = 0.8  # High relevance (evidence supports probability)
    elif question_intent == "REPURPOSING_FEASIBILITY":
        intent_relevance = 0.7  # High relevance (guidelines matter)
    elif question_intent == "MARKET_ACCESS_RISK":
        intent_relevance = 0.8  # High relevance (guidelines affect access)
    elif question_intent == "COMMERCIAL_VALUE_MAXIMIZATION":
        intent_relevance = 0.5  # Moderate relevance
    elif question_intent == "IP_OR_EXCLUSIVITY_RISK":
        intent_relevance = 0.3  # Low relevance
    elif question_intent == "PORTFOLIO_PRIORITIZATION":
        intent_relevance = 0.4  # Lower relevance
    elif question_intent == "TIME_TO_MARKET_OPTIMIZATION":
        intent_relevance = 0.5  # Moderate relevance
    
    # Generate blocking_issue
    blocking_issue = ""
    if risk_level == "High" or score < 40:
        if len(evidence) == 0:
            blocking_issue = f"Lack of scientific evidence constrains validation"
        elif evidence_strength == "Weak":
            blocking_issue = f"Weak evidence strength limits biological plausibility"
        else:
            blocking_issue = f"Scientific validation risk ({risk_level}) constrains rationale"
    
    # Generate confidence_note
    if score >= 70:
        confidence_note = f"High confidence in scientific evidence (score: {score}/100) with {len(evidence)} sources"
    elif score >= 50:
        confidence_note = f"Moderate confidence in scientific evidence (score: {score}/100) with {evidence_strength.lower()} evidence"
    else:
        confidence_note = f"Low confidence in scientific evidence (score: {score}/100) requires further validation"
    
    return {
        "agent": "regulatory",
        "summary": summary,
        "evidence": evidence,
        "confidence_level": confidence_level,
        "score": score,
        "risk_level": risk_level,
        "confidence_weight": 0.15,
        "intent_relevance": intent_relevance,
        "key_signal": key_signal,
        "blocking_issue": blocking_issue,
        "confidence_note": confidence_note,
        "justification": justification
    }


# Web Intelligence Agent ready for EY Techathon demo.

