"""
LLM Client - Centralized wrapper for language model interactions.

Supports optional OpenAI API integration. Falls back to mock/deterministic
responses when API key is not available. This design allows the prototype
to run without paid API calls while maintaining easy integration path.
"""

import os
from typing import Optional, Dict, Any
import logging

logger = logging.getLogger(__name__)

# Check for API key
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")


def call_llm(prompt: str, context: Optional[Dict[str, Any]] = None) -> str:
    """
    Call language model with a prompt and optional context.
    
    If OPENAI_API_KEY is set, attempts to call OpenAI API.
    Otherwise, returns a deterministic mock response based on the prompt and context.
    
    Args:
        prompt: The main prompt/question for the LLM
        context: Optional dictionary with additional context (e.g., data summaries)
        
    Returns:
        LLM response as a string
    """
    if OPENAI_API_KEY:
        return _call_openai_api(prompt, context)
    else:
        return _generate_mock_response(prompt, context)


def _call_openai_api(prompt: str, context: Optional[Dict[str, Any]] = None) -> str:
    """
    Call OpenAI API (GPT-3.5/GPT-4).
    
    This is a placeholder implementation. In production, you would:
    1. Import openai library
    2. Construct proper messages with system/user roles
    3. Handle rate limiting and retries
    4. Manage token limits
    
    Args:
        prompt: User prompt
        context: Optional context data
        
    Returns:
        API response or falls back to mock if API call fails
    """
    try:
        # TODO: Implement actual OpenAI API call
        # Example structure:
        # import openai
        # openai.api_key = OPENAI_API_KEY
        # response = openai.ChatCompletion.create(
        #     model="gpt-3.5-turbo",
        #     messages=[
        #         {"role": "system", "content": "You are a pharmaceutical industry analyst."},
        #         {"role": "user", "content": prompt}
        #     ]
        # )
        # return response.choices[0].message.content
        
        logger.info("OpenAI API key detected, but API call not implemented yet. Using mock response.")
        return _generate_mock_response(prompt, context)
        
    except Exception as e:
        logger.warning(f"OpenAI API call failed: {str(e)}. Falling back to mock response.")
        return _generate_mock_response(prompt, context)


def _generate_mock_response(prompt: str, context: Optional[Dict[str, Any]] = None) -> str:
    """
    Generate a deterministic mock response based on prompt and context.
    
    This provides reasonable responses for prototype demonstration without
    requiring paid API calls.
    
    Args:
        prompt: User prompt
        context: Optional context data
        
    Returns:
        Mock response string
    """
    prompt_lower = prompt.lower()
    
    # Extract key information from context if available
    context_summary = ""
    if context:
        if isinstance(context, dict):
            # Try to extract relevant data from context
            if "data" in context:
                data = context["data"]
                if isinstance(data, list) and len(data) > 0:
                    context_summary = f"Based on {len(data)} data points, "
                elif isinstance(data, dict):
                    context_summary = "Based on the provided data, "
    
    # Generate context-aware mock responses
    if "summary" in prompt_lower or "summarize" in prompt_lower:
        return f"{context_summary}The analysis reveals key market trends and opportunities. " \
               f"Market dynamics show moderate growth potential with emerging competitive pressures. " \
               f"Strategic recommendations include focusing on differentiated positioning and " \
               f"leveraging regulatory pathways for faster market entry."
    
    elif "market" in prompt_lower or "trend" in prompt_lower:
        return f"{context_summary}Market analysis indicates steady growth in the therapeutic area. " \
               f"Key drivers include increasing patient population and favorable reimbursement policies. " \
               f"Competitive landscape shows consolidation trends with several key players dominating market share."
    
    elif "patent" in prompt_lower or "intellectual property" in prompt_lower:
        return f"{context_summary}Patent landscape analysis shows active IP activity in this space. " \
               f"Key patents are approaching expiration, creating opportunities for generic entry. " \
               f"Freedom to operate analysis suggests several viable pathways for product development."
    
    elif "clinical" in prompt_lower or "trial" in prompt_lower:
        return f"{context_summary}Clinical trial data indicates promising efficacy and safety profiles. " \
               f"Phase III trials show statistically significant outcomes. Regulatory submission timelines " \
               f"appear favorable with potential for accelerated approval pathways."
    
    elif "risk" in prompt_lower or "challenge" in prompt_lower:
        return f"{context_summary}Key risks include regulatory uncertainty, competitive pressure, and " \
               f"market access challenges. Mitigation strategies should focus on early stakeholder engagement " \
               f"and robust clinical evidence generation."
    
    else:
        # Generic response
        return f"{context_summary}Analysis of the provided information indicates several strategic considerations. " \
               f"Key findings suggest opportunities for portfolio optimization and market positioning. " \
               f"Further detailed analysis would benefit from additional data sources and stakeholder input."




