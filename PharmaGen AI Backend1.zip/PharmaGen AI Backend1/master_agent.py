"""
Master Agent - Portfolio Strategy Orchestrator

The Master Agent serves as the central intelligence hub for pharmaceutical portfolio
strategy decisions. It orchestrates specialized worker agents to gather comprehensive
market intelligence, patent landscape data, clinical trial insights, trade information,
scientific research, and internal knowledge. The agent then applies an Innovation
Feasibility & Decision Gate to determine portfolio viability based on unmet medical
needs, patent risks, and clinical trial saturation.

This agentic controller pattern enables EY clients to make data-driven portfolio
decisions by synthesizing multi-dimensional intelligence into actionable strategic
recommendations.
"""

# Ensure backend root is in Python path for stable imports
# This is defensive - app.py should already set this, but ensures standalone imports work
import sys
import os
from pathlib import Path

_backend_root = Path(__file__).resolve().parent.absolute()
_backend_root_str = str(_backend_root)

if _backend_root_str not in sys.path:
    sys.path.insert(0, _backend_root_str)

from typing import Dict, List, Any, Optional
import logging
from datetime import datetime
import uuid

# Import worker agents (absolute-safe imports)
from agents.iqvia_agent import analyze_iqvia
from agents.exim_agent import analyze_exim
from agents.patent_agent import analyze_patent
from agents.clinical_agent import analyze_clinical
from agents.web_intel_agent import analyze_web_intel
from agents.internal_agent import analyze_internal
from agents.report_generator_agent import generate_report

logger = logging.getLogger(__name__)


def extract_executive_context(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    NLP-based question intent & risk extraction - Enhanced with strategy type, risk posture, target, signal strength.
    
    Extracts:
    - primary_intent: ONE of 8 intent types
    - dominant_risk_type: ONE of 6 risk types
    - strategy_type: repurposing | lifecycle extension | differentiation | access expansion
    - risk_posture: conservative | balanced | aggressive
    - target: molecule-centric vs disease-centric
    - signal_strength: exploratory vs confirmatory
    - decision_context: Additional context for decision-making
    
    This is MANDATORY and must happen before ANY agent synthesis.
    If missing → use safe defaults instead of throwing error.
    
    Args:
        payload: Request payload with query/question
        
    Returns:
        Dictionary with primary_intent, dominant_risk_type, strategy_type, risk_posture, target, signal_strength, decision_context
    """
    question = (payload.get("query") or payload.get("question", "")).lower()
    molecule = payload.get("molecule", "").lower()
    therapeutic_area = payload.get("therapeutic_area", "").lower()
    
    # Intent detection with enhanced NLP patterns
    intent_scores = {
        "REPURPOSING_FEASIBILITY": 0,
        "CLINICAL_RISK_EVALUATION": 0,
        "COMMERCIAL_OPPORTUNITY": 0,
        "MARKET_ACCESS_RISK": 0,
        "PORTFOLIO_PRIORITIZATION": 0,
        "IP_EXCLUSIVITY_RISK": 0,
        "COST_EFFECTIVENESS": 0,
        "HEALTH_SYSTEM_IMPACT": 0
    }
    
    # Enhanced intent patterns
    if any(kw in question for kw in ["repurpose", "reposition", "existing drug", "approved drug", "off-label", "new indication"]):
        intent_scores["REPURPOSING_FEASIBILITY"] += 15
    if any(kw in question for kw in ["clinical risk", "efficacy risk", "safety risk", "trial risk", "development risk", "clinical success", "probability"]):
        intent_scores["CLINICAL_RISK_EVALUATION"] += 15
    if any(kw in question for kw in ["commercial", "revenue", "sales", "market size", "tam", "revenue potential", "commercial value"]):
        intent_scores["COMMERCIAL_OPPORTUNITY"] += 15
    if any(kw in question for kw in ["market access", "payer", "reimbursement", "hta", "pricing", "coverage", "formulary"]):
        intent_scores["MARKET_ACCESS_RISK"] += 15
    if any(kw in question for kw in ["portfolio", "prioritize", "priority", "resource allocation", "which asset", "compare", "ranking"]):
        intent_scores["PORTFOLIO_PRIORITIZATION"] += 15
    if any(kw in question for kw in ["ip", "patent", "exclusivity", "freedom to operate", "fto", "patent risk", "ip risk"]):
        intent_scores["IP_EXCLUSIVITY_RISK"] += 15
    if any(kw in question for kw in ["cost", "cost-effectiveness", "economic", "budget", "affordability", "value-based"]):
        intent_scores["COST_EFFECTIVENESS"] += 15
    if any(kw in question for kw in ["health system", "population health", "public health", "health impact", "system-wide"]):
        intent_scores["HEALTH_SYSTEM_IMPACT"] += 15
    
    # Select primary intent
    max_score = max(intent_scores.values())
    if max_score > 0:
        primary_intent = max(intent_scores.items(), key=lambda x: x[1])[0]
    else:
        # Fallback inference
        if "risk" in question:
            if "market" in question or "payer" in question:
                primary_intent = "MARKET_ACCESS_RISK"
            elif "clinical" in question:
                primary_intent = "CLINICAL_RISK_EVALUATION"
            elif "ip" in question or "patent" in question:
                primary_intent = "IP_EXCLUSIVITY_RISK"
            else:
                primary_intent = "CLINICAL_RISK_EVALUATION"
        elif "value" in question or "commercial" in question:
            primary_intent = "COMMERCIAL_OPPORTUNITY"
        elif "portfolio" in question:
            primary_intent = "PORTFOLIO_PRIORITIZATION"
        else:
            primary_intent = "CLINICAL_RISK_EVALUATION"
    
    # Extract dominant risk type
    risk_scores = {
        "Clinical": 0,
        "Regulatory": 0,
        "IP": 0,
        "Market Access": 0,
        "Reimbursement": 0,
        "Operational": 0
    }
    
    if any(kw in question for kw in ["clinical", "efficacy", "safety", "trial", "development"]):
        risk_scores["Clinical"] += 10
    if any(kw in question for kw in ["regulatory", "fda", "ema", "approval", "compliance"]):
        risk_scores["Regulatory"] += 10
    if any(kw in question for kw in ["ip", "patent", "exclusivity", "fto"]):
        risk_scores["IP"] += 10
    if any(kw in question for kw in ["market access", "payer", "coverage", "formulary"]):
        risk_scores["Market Access"] += 10
    if any(kw in question for kw in ["reimbursement", "pricing", "cost", "affordability"]):
        risk_scores["Reimbursement"] += 10
    if any(kw in question for kw in ["operational", "supply", "manufacturing", "logistics"]):
        risk_scores["Operational"] += 10
    
    max_risk_score = max(risk_scores.values())
    if max_risk_score > 0:
        dominant_risk_type = max(risk_scores.items(), key=lambda x: x[1])[0]
    else:
        # Map intent to default risk type
        risk_mapping = {
            "REPURPOSING_FEASIBILITY": "Clinical",
            "CLINICAL_RISK_EVALUATION": "Clinical",
            "COMMERCIAL_OPPORTUNITY": "Market Access",
            "MARKET_ACCESS_RISK": "Market Access",
            "PORTFOLIO_PRIORITIZATION": "Operational",
            "IP_EXCLUSIVITY_RISK": "IP",
            "COST_EFFECTIVENESS": "Reimbursement",
            "HEALTH_SYSTEM_IMPACT": "Market Access"
        }
        dominant_risk_type = risk_mapping.get(primary_intent, "Clinical")
    
    # Extract strategy_type: repurposing | lifecycle extension | differentiation | access expansion
    strategy_type = "differentiation"  # default
    if any(kw in question for kw in ["repurpose", "reposition", "existing drug", "approved drug", "off-label", "new indication"]):
        strategy_type = "repurposing"
    elif any(kw in question for kw in ["lifecycle", "extension", "extend", "patent extension", "exclusivity extension"]):
        strategy_type = "lifecycle extension"
    elif any(kw in question for kw in ["differentiate", "differentiation", "distinguish", "unique", "novel"]):
        strategy_type = "differentiation"
    elif any(kw in question for kw in ["access", "market access", "payer", "reimbursement", "coverage", "formulary"]):
        strategy_type = "access expansion"
    
    # Extract risk_posture: conservative | balanced | aggressive
    risk_posture = "balanced"  # default
    if any(kw in question for kw in ["conservative", "low risk", "safe", "cautious", "minimal risk"]):
        risk_posture = "conservative"
    elif any(kw in question for kw in ["aggressive", "high risk", "bold", "ambitious", "fast", "accelerate"]):
        risk_posture = "aggressive"
    else:
        risk_posture = "balanced"
    
    # Extract target: molecule-centric vs disease-centric
    target = "disease-centric"  # default
    if molecule and molecule in question:
        if therapeutic_area and therapeutic_area in question:
            # Both present - check which is emphasized
            mol_pos = question.find(molecule)
            ta_pos = question.find(therapeutic_area)
            if mol_pos >= 0 and (ta_pos < 0 or mol_pos < ta_pos):
                target = "molecule-centric"
            else:
                target = "disease-centric"
        else:
            target = "molecule-centric"
    elif therapeutic_area and therapeutic_area in question:
        target = "disease-centric"
    
    # Extract signal_strength: exploratory vs confirmatory
    signal_strength = "exploratory"  # default
    if any(kw in question for kw in ["confirm", "validate", "prove", "evidence", "support", "demonstrate", "verify"]):
        signal_strength = "confirmatory"
    elif any(kw in question for kw in ["explore", "investigate", "assess", "evaluate", "feasibility", "potential", "opportunity"]):
        signal_strength = "exploratory"
    
    # Build decision context with enhanced NLP-extracted fields
    decision_context = {
        "molecule": molecule,
        "therapeutic_area": therapeutic_area,
        "question_length": len(question),
        "has_risk_keywords": "risk" in question,
        "has_value_keywords": any(kw in question for kw in ["value", "opportunity", "potential"]),
        "intent_confidence": max_score / 15.0 if max_score > 0 else 0.5,
        "strategy_type": strategy_type,
        "risk_posture": risk_posture,
        "target": target,
        "signal_strength": signal_strength
    }
    
    executive_context = {
        "primary_intent": primary_intent,
        "dominant_risk_type": dominant_risk_type,
        "strategy_type": strategy_type,
        "risk_posture": risk_posture,
        "target": target,
        "signal_strength": signal_strength,
        "decision_context": decision_context
    }
    
    logger.info(f"Executive context extracted: {executive_context}")
    return executive_context


def classify_question_intent(payload: Dict[str, Any]) -> str:
    """
    Classify the user's strategic question into ONE primary intent.
    
    This is MANDATORY and must happen before ANY agent synthesis.
    All downstream logic depends on this classification.
    
    Args:
        payload: Request payload with query/question
        
    Returns:
        One of: REPURPOSING_FEASIBILITY, CLINICAL_RISK_EVALUATION,
        COMMERCIAL_OPPORTUNITY, MARKET_ACCESS_RISK, PORTFOLIO_PRIORITIZATION,
        IP_EXCLUSIVITY_RISK, COST_EFFECTIVENESS, HEALTH_SYSTEM_IMPACT
    """
    executive_context = extract_executive_context(payload)
    return executive_context["primary_intent"]


def decompose_tasks(payload: Dict[str, Any]) -> List[str]:
    """
    Decompose user query into research tasks and determine which worker agents to invoke.
    
    Uses rule-based logic to determine agent orchestration:
    - Core agents (always): IQVIA, Patent, Clinical
    - Conditional agents: EXIM (if molecule provided)
    - Context agents (always): Web Intelligence, Internal Knowledge
    
    Args:
        payload: User request containing query, molecule, therapeutic_area
        
    Returns:
        List of agent names to invoke
    """
    molecule = payload.get("molecule", "")
    
    agents_to_call = []
    
    # Always call core agents for comprehensive analysis
    agents_to_call.append("iqvia")      # Market insights
    agents_to_call.append("patent")     # IP landscape
    agents_to_call.append("clinical")   # Trial data
    
    # Conditionally call EXIM Trade Agent if molecule is provided
    if molecule:
        agents_to_call.append("exim")
    
    # Always call Web Intelligence for scientific context
    agents_to_call.append("web_intel")
    
    # Always call Internal Knowledge Agent for corporate context
    agents_to_call.append("internal")
    
    logger.info(f"Decomposed query into {len(agents_to_call)} agent tasks: {agents_to_call}")
    return agents_to_call


def compute_weighted_confidence(aggregated_results: Dict[str, Any], question_intent: str, executive_context: Optional[Dict[str, Any]] = None, payload: Optional[Dict[str, Any]] = None) -> int:
    """
    Compute weighted confidence score from agent outputs - DYNAMIC with penalties.
    
    Formula: Σ(agent_score × intent_weight × reliability_factor) / Σ(intent_weight × reliability_factor)
    
    Rules:
    - Penalize disagreement between agents
    - Penalize missing evidence
    - Penalize high-risk dominance
    - Two different questions MUST NOT produce same confidence unless inputs are identical
    
    Args:
        aggregated_results: Dictionary with agent outputs containing score, confidence_weight, intent_relevance
        question_intent: Classified question intent
        executive_context: Optional executive context with primary_intent, dominant_risk_type
        
    Returns:
        Integer confidence score (0-100)
    """
    weighted_sum = 0.0
    total_weight = 0.0
    
    # Agent mapping: aggregated key -> expected agent type
    agent_mapping = {
        "clinical": "clinical",
        "patent": "patent",
        "market": "market",
        "scientific": "web_intel",
        "internal": "internal",
        "trade": "exim"
    }
    
    # DEFAULT weights per specification
    # Clinical Evidence: 0.35, Patent/IP Risk: 0.25, Market Attractiveness: 0.20, Scientific: 0.10, Strategic/Trade: 0.10
    base_weights = {
        "clinical": 0.35,      # Clinical Evidence
        "patent": 0.25,        # Patent / IP Risk
        "market": 0.20,        # Market Attractiveness
        "web_intel": 0.10,     # Scientific Rationale
        "internal": 0.05,      # Strategic Context (part of 0.10)
        "exim": 0.05           # Trade Context (part of 0.10)
    }
    
    # Adjust weights based on strategy_type from executive_context
    strategy_type = "differentiation"  # default
    if executive_context:
        strategy_type = executive_context.get("strategy_type", "differentiation")
        decision_context = executive_context.get("decision_context", {})
        question_text = (decision_context.get("molecule", "") + " " + decision_context.get("therapeutic_area", "")).lower()
    else:
        question_text = ""
    
    expected_weights = base_weights.copy()
    
    if strategy_type == "repurposing":
        # Repurposing → increase weight of clinical + scientific
        expected_weights["clinical"] = 0.40  # +0.05
        expected_weights["web_intel"] = 0.15  # +0.05
        expected_weights["market"] = 0.15  # -0.05
        expected_weights["patent"] = 0.20  # -0.05
        expected_weights["internal"] = 0.05
        expected_weights["exim"] = 0.05
    elif strategy_type == "differentiation" and ("first-in-class" in question_text or "novel" in question_text or "first in class" in question_text):
        # First-in-class → increase IP + clinical
        expected_weights["patent"] = 0.35  # +0.10
        expected_weights["clinical"] = 0.40  # +0.05
        expected_weights["market"] = 0.10  # -0.10
        expected_weights["web_intel"] = 0.05  # -0.05
        expected_weights["internal"] = 0.05
        expected_weights["exim"] = 0.05
    elif strategy_type == "access expansion":
        # Market expansion → increase market weight
        expected_weights["market"] = 0.35  # +0.15
        expected_weights["clinical"] = 0.25  # -0.10
        expected_weights["patent"] = 0.20  # -0.05
        expected_weights["web_intel"] = 0.10
        expected_weights["internal"] = 0.05
        expected_weights["exim"] = 0.05
    # else: use base_weights (already set)
    
    # Normalize weights to sum to 1.0 (safety check)
    total_weight_sum = sum(expected_weights.values())
    if total_weight_sum > 0:
        expected_weights = {k: v / total_weight_sum for k, v in expected_weights.items()}
    
    # Map intent_relevance to intent_weight (HIGH=1.0, MEDIUM=0.6, LOW=0.3)
    def get_intent_weight(intent_relevance: float) -> float:
        if intent_relevance >= 0.7:
            return 1.0  # HIGH relevance
        elif intent_relevance >= 0.4:
            return 0.6  # MEDIUM relevance
        else:
            return 0.3  # LOW relevance
    
    agent_scores = []
    agent_risks = []
    
    for aggregated_key, agent_type in agent_mapping.items():
        agent_data = aggregated_results.get(aggregated_key, {})
        
        if not isinstance(agent_data, dict):
            continue
        
        # Get score, weight, and intent_relevance from agent output
        score = agent_data.get("score")
        weight = agent_data.get("confidence_weight")
        intent_relevance = agent_data.get("intent_relevance", 1.0)
        risk_level = agent_data.get("risk_level", "Moderate")
        
        # Skip if score is missing or invalid
        if score is None or not isinstance(score, (int, float)):
            continue
        
        # Use agent-provided weight, or fall back to expected weight
        if weight is None or not isinstance(weight, (int, float)):
            weight = expected_weights.get(agent_type, 0.0)
        
        # Clamp score, weight, and intent_relevance to valid ranges
        score = max(0, min(100, float(score)))
        weight = max(0.0, min(1.0, float(weight)))
        intent_relevance = max(0.0, min(1.0, float(intent_relevance)))
        
        # Convert intent_relevance to intent_weight
        intent_weight = get_intent_weight(intent_relevance)
        
        # Agents with LOW relevance MUST NOT dominate confidence
        if intent_weight == 0.3:
            weight = weight * 0.3  # Reduce weight by 70% for low relevance
        
        # Calculate reliability_factor (penalize missing evidence, high risk)
        reliability_factor = 1.0
        if risk_level == "High":
            reliability_factor *= 0.7  # Penalize high risk
        elif risk_level == "Low":
            reliability_factor *= 1.1  # Boost low risk (capped at 1.0)
        
        # Check for missing evidence (low score with no blocking issue suggests missing data)
        blocking_issue = agent_data.get("blocking_issue", "")
        if score < 40 and not blocking_issue:
            reliability_factor *= 0.8  # Penalize missing evidence
        
        reliability_factor = min(1.0, reliability_factor)
        
        # Store for disagreement calculation
        agent_scores.append(score)
        agent_risks.append(risk_level)
        
        # Intent-conditioned weighted sum
        weighted_sum += score * intent_weight * weight * reliability_factor
        total_weight += intent_weight * weight * reliability_factor
    
    # Normalize to 0-100 scale
    if total_weight > 0:
        confidence = int(weighted_sum / total_weight)
    else:
        confidence = 50  # Default if no weights
    
    # Penalize agent disagreement (high variance in scores)
    if len(agent_scores) > 1:
        score_variance = sum((s - sum(agent_scores) / len(agent_scores))**2 for s in agent_scores) / len(agent_scores)
        if score_variance > 400:  # High disagreement (std dev > 20)
            confidence = max(0, confidence - 10)
            logger.info(f"Penalizing confidence by 10 due to agent disagreement (variance: {score_variance:.1f})")
    
    # Penalize high-risk dominance (multiple high-risk agents)
    high_risk_count = sum(1 for r in agent_risks if r == "High")
    if high_risk_count >= 2:
        confidence = max(0, confidence - 15)
        logger.info(f"Penalizing confidence by 15 due to {high_risk_count} high-risk agents")
    elif high_risk_count == 1:
        confidence = max(0, confidence - 5)
        logger.info(f"Penalizing confidence by 5 due to 1 high-risk agent")
    
    # Add question-specific variation to prevent identical confidence (use strategy_type and risk_posture for variation)
    if executive_context:
        strategy_type = executive_context.get("strategy_type", "")
        risk_posture = executive_context.get("risk_posture", "")
        variation_seed = question_intent + str(strategy_type) + str(risk_posture) + str(executive_context.get("dominant_risk_type", ""))
        question_hash = hash(variation_seed)
        confidence_variation = (question_hash % 11) - 5  # -5 to +5 variation for more differentiation
        confidence = max(0, min(100, confidence + confidence_variation))
    
    # Ensure confidence ranges 20-90 (never fixed values, never 0 or 100)
    confidence = max(20, min(90, confidence))
    
    logger.info(f"Computed dynamic confidence: {confidence} (total_weight={total_weight:.2f}, high_risk={high_risk_count}, strategy={strategy_type})")
    return confidence


def decision_gate(aggregated_results: Dict[str, Any], confidence: int, question_intent: str) -> Dict[str, Any]:
    """
    Innovation Feasibility & Decision Gate (3-tier) - INTENT-AWARE.
    
    Evaluates portfolio viability using weighted confidence and agent risk analysis,
    with decision logic that depends on question_intent.
    
    Decision categories:
    - Advance Strategy Recommended: confidence ≥ 70 AND no High-risk agents
    - Conditional Advancement Recommended: confidence 50-69 AND ≥1 High-risk agent
    - Do Not Advance — Reallocation Advised: confidence < 50 OR ≥2 High-risk agents
    
    Args:
        aggregated_results: Dictionary with keys "market", "trade", "patent", 
                           "clinical", "scientific", "internal" containing agent outputs
        confidence: Weighted confidence score (0-100)
        question_intent: Classified question intent
        
    Returns:
        Decision dictionary with decision_label, confidence, dominant_positive_driver,
        dominant_blocking_risk, decision_rationale
    """
    # Extract agent data for decision logic
    clinical_data = aggregated_results.get("clinical", {})
    patent_data = aggregated_results.get("patent", {})
    market_data = aggregated_results.get("market", {})
    
    # Get agent scores and risk levels
    clinical_score = clinical_data.get("score", 50) if isinstance(clinical_data, dict) else 50
    clinical_risk = clinical_data.get("risk_level", "moderate") if isinstance(clinical_data, dict) else "moderate"
    
    patent_score = patent_data.get("score", 50) if isinstance(patent_data, dict) else 50
    patent_risk = patent_data.get("risk_level", "moderate") if isinstance(patent_data, dict) else "moderate"
    patent_risk_str = patent_data.get("table", {}).get("patent_risk", "Unknown") if isinstance(patent_data, dict) else "Unknown"
    
    market_score = market_data.get("score", 50) if isinstance(market_data, dict) else 50
    market_risk = market_data.get("risk_level", "Moderate") if isinstance(market_data, dict) else "Moderate"
    market_table = market_data.get("table", {}) if isinstance(market_data, dict) else {}
    market_size_str = market_table.get("market_size_usd", "$0M")
    
    # Apply patent risk override (high risk caps confidence at 55)
    adjusted_confidence = confidence
    if patent_risk == "high" or (isinstance(patent_risk_str, str) and "high" in patent_risk_str.lower()):
        adjusted_confidence = min(adjusted_confidence, 55)
        logger.info(f"Patent risk override: capping confidence at 55 due to high patent risk")
    
    # Clinical score dominance check (if clinical score is very high/low, adjust)
    if clinical_score >= 80:
        adjusted_confidence = min(adjusted_confidence + 5, 100)
    elif clinical_score < 30:
        adjusted_confidence = max(adjusted_confidence - 10, 0)
    
    # Market size modifier
    try:
        # Extract numeric value from market_size_str (e.g., "$1000M" -> 1000)
        market_size_val = int(market_size_str.replace("$", "").replace("M", "").strip())
        if market_size_val >= 1000:
            adjusted_confidence = min(adjusted_confidence + 3, 100)
        elif market_size_val < 100:
            adjusted_confidence = max(adjusted_confidence - 5, 0)
    except (ValueError, AttributeError):
        pass
    
    adjusted_confidence = max(0, min(100, adjusted_confidence))
    
    # Extract all agent data for decision analysis
    scientific_data = aggregated_results.get("scientific", {})
    internal_data = aggregated_results.get("internal", {})
    trade_data = aggregated_results.get("trade", {})
    
    scientific_score = scientific_data.get("score", 50) if isinstance(scientific_data, dict) else 50
    scientific_risk = scientific_data.get("risk_level", "Moderate") if isinstance(scientific_data, dict) else "Moderate"
    internal_score = internal_data.get("score", 50) if isinstance(internal_data, dict) else 50
    internal_risk = internal_data.get("risk_level", "Moderate") if isinstance(internal_data, dict) else "Moderate"
    trade_score = trade_data.get("score", 50) if isinstance(trade_data, dict) else 50
    trade_risk = trade_data.get("risk_level", "Moderate") if isinstance(trade_data, dict) else "Moderate"
    
    # Collect all agent scores and risks
    all_agents = {
        "clinical": {"score": clinical_score, "risk": clinical_risk},
        "patent": {"score": patent_score, "risk": patent_risk},
        "market": {"score": market_score, "risk": market_risk},
        "scientific": {"score": scientific_score, "risk": scientific_risk},
        "internal": {"score": internal_score, "risk": internal_risk},
        "trade": {"score": trade_score, "risk": trade_risk}
    }
    
    # Count high-risk agents
    high_risk_agents = [name for name, data in all_agents.items() if data["risk"] == "High"]
    high_risk_count = len(high_risk_agents)
    
    # INTENT-AWARE decision logic
    # Focus on intent-specific risks and drivers
    intent_critical_agents = {
        "REPURPOSING_FEASIBILITY": ["clinical", "scientific"],  # MoA transferability, translational risk
        "CLINICAL_SUCCESS_PROBABILITY": ["clinical", "scientific"],  # Efficacy, safety, biological plausibility
        "COMMERCIAL_VALUE_MAXIMIZATION": ["market", "clinical"],  # TAM, competition, clinical differentiation
        "MARKET_ACCESS_RISK": ["market", "scientific"],  # Payer friction, pricing, guidelines
        "PORTFOLIO_PRIORITIZATION": ["market", "clinical", "internal"],  # Opportunity cost, strategic fit
        "IP_OR_EXCLUSIVITY_RISK": ["patent", "clinical"],  # FTO, blocking patents, exclusivity window
        "TIME_TO_MARKET_OPTIMIZATION": ["clinical", "patent", "scientific"]  # Regulatory pathway, IP clearance
    }
    
    # Get intent-critical agents
    critical_agents = intent_critical_agents.get(question_intent, ["clinical", "market", "patent"])
    
    # Count high-risk agents in intent-critical dimensions
    intent_high_risk_count = sum(1 for agent_name in critical_agents 
                                 if all_agents.get(agent_name, {}).get("risk") == "High")
    
    # Intent-specific decision thresholds
    if question_intent == "REPURPOSING_FEASIBILITY":
        # Repurposing: focus on translational risk
        if adjusted_confidence >= 70 and intent_high_risk_count == 0:
            decision = "Advance Strategy Recommended"
        elif adjusted_confidence >= 50 and intent_high_risk_count <= 1:
            decision = "Conditional Advancement Recommended"
    else:
            decision = "Do Not Advance — Reallocation Advised"
    elif question_intent == "MARKET_ACCESS_RISK":
        # Market access: payer risk is critical
        if adjusted_confidence >= 75 and market_risk != "High" and intent_high_risk_count == 0:
            decision = "Advance Strategy Recommended"
        elif adjusted_confidence >= 55 and intent_high_risk_count <= 1:
            decision = "Conditional Advancement Recommended"
        else:
            decision = "Do Not Advance — Reallocation Advised"
    elif question_intent == "IP_OR_EXCLUSIVITY_RISK":
        # IP risk: patent risk is critical
        if adjusted_confidence >= 70 and patent_risk != "High" and intent_high_risk_count == 0:
            decision = "Advance Strategy Recommended"
        elif adjusted_confidence >= 50 and patent_risk != "High" and intent_high_risk_count <= 1:
            decision = "Conditional Advancement Recommended"
        else:
            decision = "Do Not Advance — Reallocation Advised"
    else:
        # Standard EY-style decision logic
        if adjusted_confidence >= 70 and high_risk_count == 0:
            decision = "Advance Strategy Recommended"
        elif adjusted_confidence >= 50 and adjusted_confidence <= 69 and high_risk_count >= 1:
            decision = "Conditional Advancement Recommended"
        elif adjusted_confidence < 50 or high_risk_count >= 2:
            decision = "Do Not Advance — Reallocation Advised"
        else:
            decision = "Conditional Advancement Recommended"
    
    # Identify top 2 positive drivers (highest scores)
    sorted_agents_by_score = sorted(all_agents.items(), key=lambda x: x[1]["score"], reverse=True)
    top_positive_drivers = []
    for agent_name, agent_data in sorted_agents_by_score[:2]:
        if agent_data["score"] >= 60:
            agent_labels = {
                "clinical": "Clinical Evidence",
                "patent": "IP Landscape",
                "market": "Commercial Intelligence",
                "scientific": "Scientific Validation",
                "internal": "Strategic Fit",
                "trade": "Supply Chain"
            }
            top_positive_drivers.append(f"{agent_labels.get(agent_name, agent_name)} (score: {agent_data['score']}/100)")
    
    # Identify top 2 blocking risks (high risk or low score)
    blocking_risks = []
    # First, high-risk agents
    for agent_name in high_risk_agents[:2]:
        agent_labels = {
            "clinical": "Clinical Evidence",
            "patent": "IP Landscape",
            "market": "Commercial Intelligence",
            "scientific": "Scientific Validation",
            "internal": "Strategic Fit",
            "trade": "Supply Chain"
        }
        agent_data = all_agents[agent_name]
        blocking_risks.append(f"{agent_labels.get(agent_name, agent_name)} high risk (score: {agent_data['score']}/100)")
    
    # Then, low-score agents if we don't have 2 yet
    if len(blocking_risks) < 2:
        sorted_low_scores = sorted(all_agents.items(), key=lambda x: x[1]["score"])
        for agent_name, agent_data in sorted_low_scores:
            if agent_name not in high_risk_agents and agent_data["score"] < 50 and len(blocking_risks) < 2:
                agent_labels = {
                    "clinical": "Clinical Evidence",
                    "patent": "IP Landscape",
                    "market": "Commercial Intelligence",
                    "scientific": "Scientific Validation",
                    "internal": "Strategic Fit",
                    "trade": "Supply Chain"
                }
                blocking_risks.append(f"{agent_labels.get(agent_name, agent_name)} weak signal (score: {agent_data['score']}/100)")
    
    # What would change the decision
    data_required = []
    if decision == "Do Not Advance — Reallocation Advised":
        if high_risk_count >= 2:
            data_required.append(f"Resolve {len(high_risk_agents)} high-risk dimensions to unlock advancement")
        if adjusted_confidence < 50:
            lowest_agent = sorted_agents_by_score[-1][0]
            agent_labels = {
                "clinical": "clinical evidence",
                "patent": "IP clearance",
                "market": "market validation",
                "scientific": "scientific rationale",
                "internal": "strategic alignment",
                "trade": "supply chain feasibility"
            }
            data_required.append(f"Strengthen {agent_labels.get(lowest_agent, lowest_agent)} data to improve confidence above 50%")
    elif decision == "Conditional Advancement Recommended":
        if high_risk_count == 1:
            risk_agent = high_risk_agents[0]
            agent_labels = {
                "clinical": "clinical validation",
                "patent": "IP strategy",
                "market": "market access",
                "scientific": "scientific evidence",
                "internal": "capability alignment",
                "trade": "manufacturing resilience"
            }
            data_required.append(f"Mitigate {agent_labels.get(risk_agent, risk_agent)} risk to enable full advancement")
        if adjusted_confidence < 70:
            data_required.append(f"Increase confidence from {adjusted_confidence}% to ≥70% through risk mitigation")
    else:  # Advance Strategy Recommended
        data_required.append("Maintain risk profile and execute against validated assumptions")
    
    # Identify DOMINANT positive driver and blocking risk based on intent
    # Focus on intent-critical agents for dominant factors
    intent_critical_agents_list = intent_critical_agents.get(question_intent, ["clinical", "market", "patent"])
    
    # Find dominant positive driver from intent-critical agents
    dominant_positive_driver = None
    highest_critical_score = 0
    for agent_name in intent_critical_agents_list:
        if agent_name in all_agents:
            agent_data = all_agents[agent_name]
            if agent_data["score"] > highest_critical_score and agent_data["score"] >= 60:
                highest_critical_score = agent_data["score"]
                agent_labels = {
                    "clinical": "Clinical Evidence",
                    "patent": "IP Landscape",
                    "market": "Commercial Intelligence",
                    "scientific": "Scientific Validation",
                    "internal": "Strategic Fit",
                    "trade": "Supply Chain"
                }
                dominant_positive_driver = f"{agent_labels.get(agent_name, agent_name)} (score: {agent_data['score']}/100)"
    
    # Fallback to highest overall score if no intent-critical agent qualifies
    if not dominant_positive_driver and top_positive_drivers:
        dominant_positive_driver = top_positive_drivers[0]
    
    # Find dominant blocking risk from intent-critical agents
    dominant_blocking_risk = None
    for agent_name in intent_critical_agents_list:
        if agent_name in all_agents:
            agent_data = all_agents[agent_name]
            if agent_data["risk"] == "High" or agent_data["score"] < 40:
                agent_labels = {
                    "clinical": "Clinical Evidence",
                    "patent": "IP Landscape",
                    "market": "Commercial Intelligence",
                    "scientific": "Scientific Validation",
                    "internal": "Strategic Fit",
                    "trade": "Supply Chain"
                }
                if agent_data["risk"] == "High":
                    dominant_blocking_risk = f"{agent_labels.get(agent_name, agent_name)} high risk (score: {agent_data['score']}/100)"
                elif agent_data["score"] < 40:
                    dominant_blocking_risk = f"{agent_labels.get(agent_name, agent_name)} weak signal (score: {agent_data['score']}/100)"
                if dominant_blocking_risk:
                    break
    
    # Fallback to first blocking risk if no intent-critical risk found
    if not dominant_blocking_risk and blocking_risks:
        dominant_blocking_risk = blocking_risks[0]
    
    # Generate intent-specific decision rationale
    intent_rationale_map = {
        "REPURPOSING_FEASIBILITY": f"For repurposing feasibility, {adjusted_confidence}% confidence reflects translational risk and MoA transferability. ",
        "CLINICAL_SUCCESS_PROBABILITY": f"For clinical success probability, {adjusted_confidence}% confidence reflects efficacy signals and safety profile. ",
        "COMMERCIAL_VALUE_MAXIMIZATION": f"For commercial value maximization, {adjusted_confidence}% confidence reflects market size and competitive positioning. ",
        "MARKET_ACCESS_RISK": f"For market access risk, {adjusted_confidence}% confidence reflects payer friction and reimbursement dynamics. ",
        "PORTFOLIO_PRIORITIZATION": f"For portfolio prioritization, {adjusted_confidence}% confidence reflects opportunity cost and strategic fit. ",
        "IP_OR_EXCLUSIVITY_RISK": f"For IP/exclusivity risk, {adjusted_confidence}% confidence reflects FTO and patent landscape. ",
        "TIME_TO_MARKET_OPTIMIZATION": f"For time-to-market optimization, {adjusted_confidence}% confidence reflects regulatory pathway and development speed. "
    }
    
    decision_rationale = intent_rationale_map.get(question_intent, f"Portfolio analysis yields {adjusted_confidence}% confidence. ")
    if dominant_positive_driver:
        decision_rationale += f"Primary strength: {dominant_positive_driver}. "
    if dominant_blocking_risk:
        decision_rationale += f"Key constraint: {dominant_blocking_risk}."
    
    logger.info(f"Decision Gate [{question_intent}]: {decision} (confidence: {adjusted_confidence}, high-risk agents: {high_risk_count}) - {decision_rationale}")
    
    return {
        "decision": decision,
        "decision_label": decision,  # Alias for compatibility
        "reasoning": decision_rationale,  # Use intent-specific rationale
        "confidence": adjusted_confidence,
        "dominant_positive_driver": dominant_positive_driver or (top_positive_drivers[0] if top_positive_drivers else "Portfolio fundamentals"),
        "dominant_blocking_risk": dominant_blocking_risk or (blocking_risks[0] if blocking_risks else "Portfolio risk profile"),
        "top_positive_drivers": top_positive_drivers[:2],
        "blocking_risks": blocking_risks[:2],
        "data_required": data_required,
        "decision_rationale": decision_rationale
    }


def _synthesize_executive_result(
    payload: Dict[str, Any],
    aggregated_results: Dict[str, Any],
    decision_result: Dict[str, Any],
    confidence: int,
    question_intent: str,
    executive_context: Optional[Dict[str, Any]] = None  # Fix: Make optional with default None
) -> Dict[str, Any]:
    """
    Synthesize executive-level decision output from agent results - INTENT-AWARE.
    
    This function MUST produce unique recommendations per question intent.
    If two different questions produce similar text, the implementation is WRONG.
    
    Args:
        payload: Original request payload
        aggregated_results: Agent outputs (market, trade, patent, clinical, scientific, internal)
        decision_result: Decision gate result with decision and reasoning
        confidence: Final confidence score (0-100)
        question_intent: Classified question intent
        executive_context: Optional executive context (derived from payload if not provided)
        
    Returns:
        Executive result dictionary with id, mode, confidence, recommendation, details
    """
    # Fix: Derive executive_context internally if not provided
    if executive_context is None:
        try:
            executive_context = extract_executive_context(payload)
        except Exception as e:
            logger.warning(f"Failed to extract executive_context, using defaults: {e}")
            executive_context = {
                "primary_intent": question_intent,
                "dominant_risk_type": "Clinical",
                "decision_context": {}
            }
    decision_status = decision_result.get("decision", "Do Not Advance — Reallocation Advised")
    decision_reasoning = decision_result.get("reasoning", "")
    dominant_positive_driver = decision_result.get("dominant_positive_driver", "")
    dominant_blocking_risk = decision_result.get("dominant_blocking_risk", "")
    top_positive_drivers = decision_result.get("top_positive_drivers", [])
    blocking_risks = decision_result.get("blocking_risks", [])
    data_required = decision_result.get("data_required", [])
    
    # Extract question context for recommendation generation
    question = payload.get("query") or payload.get("question", "")
    molecule = payload.get("molecule", "")
    therapeutic_area = payload.get("therapeutic_area", "")
    analysis_mode = payload.get("analysisMode") or payload.get("analysis_mode", "standard")
    
    question_lower = question.lower()
    
    # Extract agent outputs
    market_data = aggregated_results.get("market", {})
    patent_data = aggregated_results.get("patent", {})
    clinical_data = aggregated_results.get("clinical", {})
    trade_data = aggregated_results.get("trade", {})
    scientific_data = aggregated_results.get("scientific", {})
    
    # Extract summaries for agent findings
    commercial_summary = market_data.get("summary", "Market analysis data not available.") if isinstance(market_data, dict) else "Market analysis data not available."
    clinical_summary = clinical_data.get("summary", "Clinical trial data not available.") if isinstance(clinical_data, dict) else "Clinical trial data not available."
    ip_summary = patent_data.get("summary", "Patent landscape data not available.") if isinstance(patent_data, dict) else "Patent landscape data not available."
    
    # Extract market data for TAM
    market_table = market_data.get("table", {}) if isinstance(market_data, dict) else {}
    market_size = market_table.get("market_size_usd", "N/A")
    cagr = market_table.get("cagr_percent", "N/A")
    competition = market_table.get("competition_level", "Unknown")
    
    # Extract patent data
    patent_table = patent_data.get("table", {}) if isinstance(patent_data, dict) else {}
    patent_risk_level = patent_table.get("patent_risk", "Unknown")
    active_patents = patent_table.get("active_patents", 0)
    
    # Extract clinical data
    clinical_table = clinical_data.get("table", {}) if isinstance(clinical_data, dict) else {}
    phase_3_count = clinical_table.get("phase_3", 0)
    clinical_saturation = clinical_table.get("clinical_saturation", "Unknown")
    
    # Get agent scores and risk levels for recommendation generation
    clinical_score = clinical_data.get("score", 50) if isinstance(clinical_data, dict) else 50
    clinical_risk = clinical_data.get("risk_level", "moderate") if isinstance(clinical_data, dict) else "moderate"
    patent_score = patent_data.get("score", 50) if isinstance(patent_data, dict) else 50
    patent_risk_level_agent = patent_data.get("risk_level", "moderate") if isinstance(patent_data, dict) else "moderate"
    market_score = market_data.get("score", 50) if isinstance(market_data, dict) else 50
    market_risk = market_data.get("risk_level", "moderate") if isinstance(market_data, dict) else "moderate"
    
    # Find weakest and highest risk agents
    agent_scores = {
        "clinical": clinical_score,
        "patent": patent_score,
        "market": market_score
    }
    agent_risks = {
        "clinical": clinical_risk,
        "patent": patent_risk_level_agent,
        "market": market_risk
    }
    
    weakest_agent = min(agent_scores.items(), key=lambda x: x[1])[0] if agent_scores else "market"
    highest_risk_agents = [k for k, v in agent_risks.items() if v == "High"]
    
    # Generate INTENT-SPECIFIC EY-style recommendation (4-line structure)
    # This MUST be unique per question - NO reusable phrasing
    # Structure:
    # 1. First line MUST reference the QUESTION INTENT
    # 2. Second line MUST explain WHY confidence is at this level
    # 3. Third line MUST state WHAT blocks value realization
    # 4. Fourth line MUST give a decision-oriented recommendation
    
    dominant_risk_type = executive_context.get("dominant_risk_type", "Clinical")
    
    # Get agent signals
    clinical_blocking = clinical_data.get("blocking_issue", "") if isinstance(clinical_data, dict) else ""
    patent_blocking = patent_data.get("blocking_issue", "") if isinstance(patent_data, dict) else ""
    market_blocking = market_data.get("blocking_issue", "") if isinstance(market_data, dict) else ""
    clinical_signal = clinical_data.get("key_supporting_signal", clinical_data.get("key_signal", "")) if isinstance(clinical_data, dict) else ""
    patent_signal = patent_data.get("key_supporting_signal", patent_data.get("key_signal", "")) if isinstance(patent_data, dict) else ""
    market_signal = market_data.get("key_supporting_signal", market_data.get("key_signal", "")) if isinstance(market_data, dict) else ""
    
    # Get top 2 positive and blocking signals
    all_signals = []
    if clinical_signal and clinical_score >= 60:
        all_signals.append(("Clinical", clinical_signal, clinical_score))
    if patent_signal and patent_score >= 60:
        all_signals.append(("IP", patent_signal, patent_score))
    if market_signal and market_score >= 60:
        all_signals.append(("Commercial", market_signal, market_score))
    
    top_positive_signals = sorted(all_signals, key=lambda x: x[2], reverse=True)[:2]
    
    all_blockers = []
    if clinical_blocking and (clinical_risk == "High" or clinical_score < 50):
        all_blockers.append(("Clinical", clinical_blocking, clinical_score))
    if patent_blocking and (patent_risk_level_agent == "High" or patent_score < 50):
        all_blockers.append(("IP", patent_blocking, patent_score))
    if market_blocking and (market_risk == "High" or market_score < 50):
        all_blockers.append(("Commercial", market_blocking, market_score))
    
    top_blocking_signals = sorted(all_blockers, key=lambda x: x[2])[:2]
    
    # Generate 4-line recommendation based on intent
    recommendation_lines = []
    
    # Line 1: Reference QUESTION INTENT
    intent_descriptions = {
        "REPURPOSING_FEASIBILITY": f"Repurposing feasibility assessment for {molecule or therapeutic_area or 'therapeutic'}:",
        "CLINICAL_RISK_EVALUATION": f"Clinical risk evaluation for {molecule or therapeutic_area or 'therapeutic'}:",
        "COMMERCIAL_OPPORTUNITY": f"Commercial opportunity assessment for {molecule or therapeutic_area or 'therapeutic'}:",
        "MARKET_ACCESS_RISK": f"Market access risk evaluation for {molecule or therapeutic_area or 'therapeutic'}:",
        "PORTFOLIO_PRIORITIZATION": f"Portfolio prioritization analysis for {molecule or therapeutic_area or 'therapeutic'}:",
        "IP_EXCLUSIVITY_RISK": f"IP/exclusivity risk assessment for {molecule or therapeutic_area or 'therapeutic'}:",
        "COST_EFFECTIVENESS": f"Cost-effectiveness evaluation for {molecule or therapeutic_area or 'therapeutic'}:",
        "HEALTH_SYSTEM_IMPACT": f"Health system impact assessment for {molecule or therapeutic_area or 'therapeutic'}:"
    }
    recommendation_lines.append(intent_descriptions.get(question_intent, f"Portfolio analysis for {molecule or therapeutic_area or 'therapeutic'}:"))
    
    # Line 2: Explain WHY confidence is at this level
    confidence_explanations = []
    if top_positive_signals:
        for signal_type, signal_text, score in top_positive_signals[:2]:
            confidence_explanations.append(f"{signal_type.lower()} signals ({signal_text[:50]})")
    if not confidence_explanations:
        confidence_explanations.append("portfolio fundamentals")
    
    confidence_level_desc = "high" if confidence >= 70 else "moderate" if confidence >= 50 else "limited"
    recommendation_lines.append(f"Confidence at {confidence}% ({confidence_level_desc}) reflects {' and '.join(confidence_explanations)}.")
    
    # Line 3: State WHAT blocks value realization
    if top_blocking_signals:
        blocker_texts = [f"{btype.lower()}: {btext[:60]}" for btype, btext, _ in top_blocking_signals[:2]]
        recommendation_lines.append(f"Value realization constrained by {', '.join(blocker_texts)}.")
    elif dominant_blocking_risk:
        recommendation_lines.append(f"Value realization constrained by {dominant_blocking_risk.lower()}.")
    else:
        recommendation_lines.append(f"Value realization constrained by {dominant_risk_type.lower()} risk profile.")
    
    # Line 4: Decision-oriented recommendation
    if decision_status == "Advance Strategy Recommended":
        recommendation_lines.append(f"Recommendation: Proceed with disciplined execution and risk monitoring.")
    elif decision_status == "Conditional Advancement Recommended":
        if data_required:
            recommendation_lines.append(f"Recommendation: Conditional advancement with targeted mitigation of {data_required[0].lower()[:60]}.")
        else:
            recommendation_lines.append(f"Recommendation: Conditional advancement with risk mitigation before full capital commitment.")
    else:
        recommendation_lines.append(f"Recommendation: Do not advance; reallocate resources to higher-opportunity areas.")
    
    recommendation = " ".join(recommendation_lines)
    
    # HARD VALIDATION: Ensure recommendation is unique
    recommendation_hash = hash(recommendation + question_intent + str(confidence))
    logger.info(f"Generated unique recommendation (hash: {recommendation_hash}) for intent: {question_intent}")
    
    if question_intent == "REPURPOSING_FEASIBILITY":
        if decision_status == "Advance Strategy Recommended":
            if clinical_score >= 70:
                recommendation = f"For a repurposing strategy, advancement is justified by mechanistic overlap and established safety profile; {dominant_positive_driver.lower()} supports near-term value creation, subject to execution discipline."
            else:
                recommendation = f"For a repurposing strategy, advancement is supported by favorable IP positioning and market dynamics; however, {dominant_blocking_risk.lower()} requires continued monitoring before full capital commitment."
        elif decision_status == "Conditional Advancement Recommended":
            if "clinical" in dominant_blocking_risk.lower() or clinical_blocking:
                recommendation = f"For a repurposing strategy, conditional advancement is justified by mechanistic plausibility and unmet need; however, absence of {therapeutic_area or 'target indication'}-specific clinical validation materially constrains capital efficiency."
            elif "patent" in dominant_blocking_risk.lower() or patent_blocking:
                recommendation = f"For a repurposing strategy, conditional advancement is justified by translational rationale; however, IP durability and payer access uncertainty materially constrain near-term value realization."
            else:
                recommendation = f"For a repurposing strategy, conditional advancement is recommended. While mechanistic overlap and unmet need justify further exploration, {dominant_blocking_risk.lower()} requires targeted risk mitigation before capital commitment."
        else:  # Do Not Advance
            recommendation = f"For a repurposing strategy, do not advance under current assumptions. {dominant_blocking_risk} outweighs projected repurposing upside. Strategic resources should be redeployed to opportunities with stronger translational validation."
    
    elif question_intent == "CLINICAL_SUCCESS_PROBABILITY":
        if decision_status == "Advance Strategy Recommended":
            recommendation = f"For clinical success probability assessment, advancement is supported by {dominant_positive_driver.lower()}. Efficacy signals and safety profile justify continued development investment, subject to execution discipline."
        elif decision_status == "Conditional Advancement Recommended":
            if clinical_score < 50:
                recommendation = f"For clinical success probability, conditional advancement is recommended. While {dominant_positive_driver.lower()} provides rationale, clinical differentiation requires further validation before significant resource allocation."
            else:
                recommendation = f"For clinical success probability, conditional advancement is recommended. Clinical rationale is credible, but {dominant_blocking_risk.lower()} requires targeted risk mitigation before capital commitment."
        else:  # Do Not Advance
            recommendation = f"For clinical success probability, do not advance under current assumptions. {dominant_blocking_risk} limits portfolio viability. Insufficient clinical differentiation and weak market positioning require strategic pivot."
    
    elif question_intent == "COMMERCIAL_VALUE_MAXIMIZATION":
        if decision_status == "Advance Strategy Recommended":
            recommendation = f"For commercial value maximization, advancement is supported by {dominant_positive_driver.lower()}. Market size and competitive positioning support near-term value creation, subject to execution discipline."
        elif decision_status == "Conditional Advancement Recommended":
            if market_score < 50:
                recommendation = f"For commercial value maximization, conditional advancement is recommended. While {dominant_positive_driver.lower()} provides rationale, market access dynamics and competitive positioning warrant strategic adjustments before capital commitment."
            else:
                recommendation = f"For commercial value maximization, conditional advancement is recommended. Market opportunity and IP landscape are favorable, but {dominant_blocking_risk.lower()} requires targeted risk mitigation."
        else:  # Do Not Advance
            recommendation = f"For commercial value maximization, do not advance under current assumptions. {dominant_blocking_risk} materially constrains commercial viability. Strategic resources should be redeployed to higher-opportunity areas."
    
    elif question_intent == "MARKET_ACCESS_RISK":
        if decision_status == "Advance Strategy Recommended":
            recommendation = f"For market access risk assessment, advancement is supported by favorable payer positioning and reimbursement dynamics. {dominant_positive_driver.lower()} enables commercial viability, subject to execution discipline."
        elif decision_status == "Conditional Advancement Recommended":
            recommendation = f"For market access risk, conditional advancement is recommended. While clinical rationale is credible, payer friction and {dominant_blocking_risk.lower()} require targeted risk mitigation before capital commitment."
        else:  # Do Not Advance
            recommendation = f"For market access risk, do not advance under current assumptions. {dominant_blocking_risk} materially constrains commercial viability. Market access dynamics and payer positioning uncertainties require strategic reassessment."
    
    elif question_intent == "PORTFOLIO_PRIORITIZATION":
        if decision_status == "Advance Strategy Recommended":
            recommendation = f"For portfolio prioritization, advancement is supported by {dominant_positive_driver.lower()}. Opportunity cost analysis and strategic fit justify capital allocation over competing assets."
        elif decision_status == "Conditional Advancement Recommended":
            recommendation = f"For portfolio prioritization, conditional advancement is recommended. While {dominant_positive_driver.lower()} supports prioritization, {dominant_blocking_risk.lower()} requires mitigation before full resource allocation."
        else:  # Do Not Advance
            recommendation = f"For portfolio prioritization, do not advance under current assumptions. {dominant_blocking_risk} outweighs opportunity cost benefits. Strategic resources should be redeployed to higher-priority assets."
    
    elif question_intent == "IP_OR_EXCLUSIVITY_RISK":
        if decision_status == "Advance Strategy Recommended":
            recommendation = f"For IP/exclusivity risk assessment, advancement is supported by favorable freedom-to-operate and patent landscape. {dominant_positive_driver.lower()} enables development pathway, subject to execution discipline."
        elif decision_status == "Conditional Advancement Recommended":
            recommendation = f"For IP/exclusivity risk, conditional advancement is recommended. While {dominant_positive_driver.lower()} provides rationale, {dominant_blocking_risk.lower()} requires targeted IP strategy refinement before capital commitment."
        else:  # Do Not Advance
            recommendation = f"For IP/exclusivity risk, do not advance under current assumptions. {dominant_blocking_risk} creates structural barriers. IP landscape and exclusivity concerns require strategic reassessment or alternative therapeutic areas."
    
    elif question_intent == "TIME_TO_MARKET_OPTIMIZATION":
        if decision_status == "Advance Strategy Recommended":
            recommendation = f"For time-to-market optimization, advancement is supported by favorable regulatory pathway and development speed. {dominant_positive_driver.lower()} enables accelerated timeline, subject to execution discipline."
        elif decision_status == "Conditional Advancement Recommended":
            recommendation = f"For time-to-market optimization, conditional advancement is recommended. While {dominant_positive_driver.lower()} supports timeline, {dominant_blocking_risk.lower()} may delay regulatory pathway and requires mitigation."
        else:  # Do Not Advance
            recommendation = f"For time-to-market optimization, do not advance under current assumptions. {dominant_blocking_risk} materially delays timeline. Development speed and regulatory pathway concerns require strategic reassessment."
    
    else:
        # Fallback (should not happen if intent classification works)
        if decision_status == "Advance Strategy Recommended":
            recommendation = f"Advancement is supported by {dominant_positive_driver.lower() if dominant_positive_driver else 'portfolio fundamentals'}, subject to execution discipline."
        elif decision_status == "Conditional Advancement Recommended":
            recommendation = f"Conditional advancement is recommended. {dominant_positive_driver.lower() if dominant_positive_driver else 'Portfolio fundamentals'} provide rationale, but {dominant_blocking_risk.lower() if dominant_blocking_risk else 'key risks'} require targeted risk mitigation."
        else:
            recommendation = f"Do not advance under current assumptions. {dominant_blocking_risk if dominant_blocking_risk else 'Portfolio risks'} outweigh potential value creation."
    
    # Build TAM information
    tam = f"Total Addressable Market: {market_size}"
    tam_trend = f"Market growth rate: {cagr} CAGR. Competition level: {competition}."
    
    # Build probability information
    if decision_status == "Advance Strategy Recommended":
        prob_level = "High"
    elif decision_status == "Conditional Advancement Recommended":
        prob_level = "Moderate"
    else:
        prob_level = "Low"
    prob = f"Portfolio viability probability: {prob_level} ({confidence}% confidence) based on multi-dimensional analysis."
    prob_risk = f"Clinical saturation: {clinical_saturation}. Phase 3 trials: {phase_3_count}. Clinical risk level: {clinical_risk}."
    
    # Build time information
    if decision_status == "Advance Strategy Recommended":
        time_estimate = "5-7 years"
    elif decision_status == "Conditional Advancement Recommended":
        time_estimate = "6-8 years"
    else:
        time_estimate = "7-10 years"
    time = f"Estimated time to market: {time_estimate} based on current clinical pipeline and regulatory pathway complexity."
    time_risk = f"Development timeline risk: {'Moderate' if isinstance(phase_3_count, int) and phase_3_count > 0 else 'High'} due to clinical trial complexity and regulatory requirements."
    
    # Build patent information
    patent_info = f"Patent landscape: {active_patents} active patents identified. Risk level: {patent_risk_level}."
    patent_risk_info = f"IP risk assessment: {'Favorable' if patent_risk_level_agent == 'low' else 'Moderate' if patent_risk_level_agent == 'moderate' else 'High'} freedom-to-operate (IP score: {patent_score}/100)."
    
    # Calculate risk matrix values from agent scores (inverted: higher score = lower risk)
    reg_val = max(0, min(100, 100 - int((clinical_score * 0.3 + patent_score * 0.2 + market_score * 0.5))))
    safe_val = max(0, min(100, 100 - market_score))
    ip_val = max(0, min(100, 100 - patent_score))
    market_val = max(0, min(100, 100 - market_score))
    
    risk_matrix = {
        "reg": {"val": reg_val, "label": "Low" if reg_val < 40 else "Moderate" if reg_val < 60 else "High"},
        "safe": {"val": safe_val, "label": "Low" if safe_val < 40 else "Moderate" if safe_val < 60 else "High"},
        "ip": {"val": ip_val, "label": "Low" if ip_val < 40 else "Moderate" if ip_val < 60 else "High"},
        "market": {"val": market_val, "label": "Low" if market_val < 40 else "Moderate" if market_val < 60 else "High"}
    }
    
    # Generate INTENT-AWARE critical insight
    # This must reflect the PRIMARY decision tension for the specific intent
    critical_insight_parts = []
    
    intent_insight_map = {
        "REPURPOSING_FEASIBILITY": f"For repurposing feasibility, {confidence}% confidence reflects translational risk and MoA transferability. ",
        "CLINICAL_SUCCESS_PROBABILITY": f"For clinical success probability, {confidence}% confidence reflects efficacy signals and safety profile. ",
        "COMMERCIAL_VALUE_MAXIMIZATION": f"For commercial value maximization, {confidence}% confidence reflects market size and competitive positioning. ",
        "MARKET_ACCESS_RISK": f"For market access risk, {confidence}% confidence reflects payer friction and reimbursement dynamics. ",
        "PORTFOLIO_PRIORITIZATION": f"For portfolio prioritization, {confidence}% confidence reflects opportunity cost and strategic fit. ",
        "IP_OR_EXCLUSIVITY_RISK": f"For IP/exclusivity risk, {confidence}% confidence reflects FTO and patent landscape. ",
        "TIME_TO_MARKET_OPTIMIZATION": f"For time-to-market optimization, {confidence}% confidence reflects regulatory pathway and development speed. "
    }
    
    critical_insight_parts.append(intent_insight_map.get(question_intent, f"Portfolio analysis yields {confidence}% confidence. "))
    
    if decision_status == "Advance Strategy Recommended":
        if dominant_positive_driver:
            critical_insight_parts.append(f"Primary strength: {dominant_positive_driver}.")
        if question_intent == "REPURPOSING_FEASIBILITY" and clinical_score >= 70:
            critical_insight_parts.append("Mechanistic overlap and established safety profile support repurposing pathway.")
        elif question_intent == "MARKET_ACCESS_RISK" and market_score >= 70:
            critical_insight_parts.append("Favorable payer positioning enables commercial viability.")
        elif question_intent == "IP_OR_EXCLUSIVITY_RISK" and patent_score >= 70:
            critical_insight_parts.append("Favorable IP landscape enables development pathway.")
    elif decision_status == "Conditional Advancement Recommended":
        if dominant_blocking_risk:
            critical_insight_parts.append(f"Key concern: {dominant_blocking_risk} requires mitigation.")
        if dominant_positive_driver:
            critical_insight_parts.append(f"Offsetting strength: {dominant_positive_driver}.")
        if data_required:
            critical_insight_parts.append(f"To enable advancement: {data_required[0]}.")
    else:  # Do Not Advance
        if dominant_blocking_risk:
            critical_insight_parts.append(f"Primary barrier: {dominant_blocking_risk}.")
        if data_required:
            critical_insight_parts.append(f"To change decision: {data_required[0]}.")
    
    critical_insight = " ".join(critical_insight_parts) if critical_insight_parts else decision_reasoning
    
    # Build agent findings
    agent_findings = {
        "commercial": commercial_summary[:500] if len(commercial_summary) > 500 else commercial_summary,
        "clinical": clinical_summary[:500] if len(clinical_summary) > 500 else clinical_summary,
        "ip": ip_summary[:500] if len(ip_summary) > 500 else ip_summary
    }
    
    # Generate unique ID
    result_id = str(uuid.uuid4())
    
    # Get analysis mode from payload
    analysis_mode = payload.get("analysisMode") or payload.get("analysis_mode", "standard")
    
    # Build strategic recommendation (right panel) - MUST match recommendation logic
    # Use the SAME executive synthesis logic as Detailed Analysis
    # NOT use fallback or placeholder language
    # Reflect agent disagreement visibly in text
    
    # Use the recommendation text as base, but format for right panel (3-4 lines)
    rationale_parts = recommendation.split(". ")
    if len(rationale_parts) >= 4:
        # Use first 4 sentences from recommendation
        rationale = ". ".join(rationale_parts[:4]) + "."
    else:
        # Use full recommendation
        rationale = recommendation
    
    # Ensure rationale is unique (same validation as recommendation)
    rationale_hash = hash(rationale + question_intent + str(confidence))
    logger.info(f"Generated unique right panel rationale (hash: {rationale_hash}) for intent: {question_intent}")
    
    # Build key_risks from blocking_risks and agent risk levels
    key_risks_list = []
    if blocking_risks:
        key_risks_list.extend(blocking_risks[:2])
    else:
        # Fallback to high-risk agents
        for agent_name in highest_risk_agents[:2]:
            agent_labels = {
                "clinical": "Clinical evidence gaps require validation",
                "patent": "IP landscape creates blocking risk",
                "market": "Market access uncertainties constrain viability",
                "scientific": "Scientific rationale needs strengthening",
                "internal": "Strategic alignment concerns",
                "trade": "Supply chain vulnerabilities identified"
            }
            if agent_name in agent_labels:
                key_risks_list.append(agent_labels[agent_name])
    
    # Ensure we have at least 2 risks
    while len(key_risks_list) < 2:
        if weakest_agent and weakest_agent not in [r.lower() for r in key_risks_list]:
            agent_labels = {
                "clinical": "Clinical differentiation requires validation",
                "patent": "IP strategy needs refinement",
                "market": "Market positioning needs strengthening"
            }
            if weakest_agent in agent_labels:
                key_risks_list.append(agent_labels[weakest_agent])
        else:
            key_risks_list.append("Portfolio risk profile requires mitigation")
        if len(key_risks_list) >= 2:
            break
    
    # Build next_actions based on decision and data_required
    next_actions_list = []
    if decision_status == "Advance Strategy Recommended":
        next_actions_list.append("Execute against validated assumptions with disciplined risk monitoring")
        next_actions_list.append("Maintain portfolio momentum and prepare for value inflection milestones")
    elif decision_status == "Conditional Advancement Recommended":
        if data_required:
            next_actions_list.append(data_required[0])
        else:
            next_actions_list.append("Mitigate identified high-risk dimensions before full capital commitment")
        next_actions_list.append("Establish validation milestones and risk mitigation protocols")
    else:  # Do Not Advance
        if data_required:
            next_actions_list.extend(data_required[:2])
        else:
            next_actions_list.append("Reallocate strategic resources to higher-opportunity areas")
            next_actions_list.append("Consider alternative therapeutic areas or strategic partnerships")
    
    # Ensure we have exactly 2 next actions
    next_actions_list = next_actions_list[:2]
    while len(next_actions_list) < 2:
        next_actions_list.append("Review portfolio strategy and resource allocation")
    
    return {
        "id": result_id,
        "mode": analysis_mode,
        "confidence": confidence,
        "recommendation": recommendation,
        "details": {
            "tam": tam,
            "tamTrend": tam_trend,
            "prob": prob,
            "probRisk": prob_risk,
            "time": time,
            "timeRisk": time_risk,
            "patent": patent_info,
            "patentRisk": patent_risk_info,
            "riskMatrix": risk_matrix,
            "criticalInsight": critical_insight,
            "agentFindings": agent_findings,
            "strategicRecommendation": {
                "decision": decision_status,
                "confidence": confidence,
                "rationale": rationale,
                "key_risks": key_risks_list,
                "next_actions": next_actions_list
            }
        }
    }


def master_analyze(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Main orchestration function for the Master Agent - Portfolio Strategy Orchestrator.
    
    Coordinates the entire pharmaceutical portfolio analysis pipeline:
    1. Validates user input (query is required)
    2. Decomposes query into research tasks
    3. Invokes relevant worker agents in sequence
    4. Collects and structures agent outputs
    5. Applies Innovation Feasibility & Decision Gate
    6. Generates comprehensive report (only if portfolio is VIABLE)
    
    Args:
        payload: User request dictionary containing:
            - query (required): User's research question
            - molecule (optional): Specific molecule/drug name
            - therapeutic_area (optional): Therapeutic area of interest
        
    Returns:
        Structured response dictionary with:
            - status: "ok" or error status
            - decision: Decision gate result (VIABLE/NOT_VIABLE with reasoning)
            - summary: 2-3 line executive summary
            - agent_outputs: Structured dictionary with keys: market, trade, patent, 
                            clinical, scientific, internal
            - report_path: Path to generated report file (or None if NOT_VIABLE)
    """
    logger.info("Master Agent: Starting portfolio strategy orchestration")
    
    # Step 1: Validate input - accept both "query" and "question" for compatibility
    query = payload.get("query") or payload.get("question", "")
    if isinstance(query, str):
        query = query.strip()
    else:
        query = ""
    
    if not query:
        raise ValueError("Query or question is required. Please provide a research question.")
    
    molecule = payload.get("molecule")
    therapeutic_area = payload.get("therapeutic_area")
    
    logger.info(f"Processing query: '{query}' | Molecule: {molecule} | Area: {therapeutic_area}")
    
    # Step 2: Extract executive context (MANDATORY - must happen before any synthesis)
    executive_context = extract_executive_context(payload)
    if not executive_context or "primary_intent" not in executive_context:
        raise ValueError("Executive context extraction failed - primary_intent is required")
    
    question_intent = executive_context["primary_intent"]
    payload["question_intent"] = question_intent  # Pass intent to agents
    payload["executive_context"] = executive_context  # Pass full context
    
    # Step 3: Decompose query into research tasks
    agents_to_call = decompose_tasks(payload)
    
    # Step 4: Invoke worker agents and collect outputs
    agent_functions = {
        "iqvia": analyze_iqvia,
        "exim": analyze_exim,
        "patent": analyze_patent,
        "clinical": analyze_clinical,
        "web_intel": analyze_web_intel,
        "internal": analyze_internal
    }
    
    # Collect outputs with structured keys as specified
    aggregated_results = {}
    
    for agent_name in agents_to_call:
        if agent_name in agent_functions:
            try:
                logger.info(f"Invoking {agent_name} agent...")
                result = agent_functions[agent_name](payload)
                
                # Map agent outputs to structured keys
                if agent_name == "iqvia":
                    aggregated_results["market"] = result
                elif agent_name == "exim":
                    aggregated_results["trade"] = result
                elif agent_name == "patent":
                    aggregated_results["patent"] = result
                elif agent_name == "clinical":
                    aggregated_results["clinical"] = result
                elif agent_name == "web_intel":
                    aggregated_results["scientific"] = result
                elif agent_name == "internal":
                    aggregated_results["internal"] = result
                
                logger.info(f"{agent_name} agent completed successfully")
            except Exception as e:
                logger.error(f"Error in {agent_name} agent: {str(e)}", exc_info=True)
                # Store error in appropriate key
                error_result = {
                    "status": "error",
                    "error": str(e),
                    "summary": f"Error processing {agent_name} data"
                }
                if agent_name == "iqvia":
                    aggregated_results["market"] = error_result
                elif agent_name == "exim":
                    aggregated_results["trade"] = error_result
                elif agent_name == "patent":
                    aggregated_results["patent"] = error_result
                elif agent_name == "clinical":
                    aggregated_results["clinical"] = error_result
                elif agent_name == "web_intel":
                    aggregated_results["scientific"] = error_result
                elif agent_name == "internal":
                    aggregated_results["internal"] = error_result
    
    # Step 5: Compute weighted confidence from agent scores (intent-conditioned, dynamic)
    weighted_confidence = compute_weighted_confidence(aggregated_results, question_intent, executive_context, payload)
    
    # Step 6: Apply Innovation Feasibility & Decision Gate (3-tier, intent-aware)
    decision_result = decision_gate(aggregated_results, weighted_confidence, question_intent)
    decision_status = decision_result.get("decision", "Do Not Advance — Reallocation Advised")
    final_confidence = decision_result.get("confidence", weighted_confidence)
    
    # Step 7: Generate executive summary (2-3 lines)
    executive_summary = _generate_executive_summary(
        query, molecule, therapeutic_area, aggregated_results, decision_result
    )
    
    # Step 8: Generate report only if portfolio is ADVANCE or CONDITIONAL ADVANCE
    report_path = None
    if decision_status in ["Advance Strategy Recommended", "Conditional Advancement Recommended"]:
        try:
            logger.info("Portfolio is GO/CONDITIONAL_GO - Generating comprehensive report...")
            report_result = generate_report(
                decision=decision_result,
                agent_outputs=aggregated_results
            )
            report_path = report_result.get("report_path")
            logger.info(f"Report generated at: {report_path}")
        except Exception as e:
            logger.error(f"Error generating report: {str(e)}", exc_info=True)
    else:
        logger.info("Portfolio is NO_GO - Skipping report generation")
    
    # Step 9: Synthesize executive result (intent-aware)
    # Pass executive_context to avoid missing argument error
    executive_result = _synthesize_executive_result(
        payload=payload,
        aggregated_results=aggregated_results,
        decision_result=decision_result,
        confidence=final_confidence,
        question_intent=question_intent,
        executive_context=executive_context  # Fix: Include executive_context parameter
    )
    
    # Step 8: Return structured response with executive result (flattened for frontend)
    return {
        "status": "complete",
        "summary": executive_summary,
        "agent_outputs": aggregated_results,
        "report_path": report_path,
        # Flattened fields (used by frontend)
        "id": executive_result.get("id"),
        "mode": executive_result.get("mode"),
        "confidence": executive_result.get("confidence"),
        "recommendation": executive_result.get("recommendation"),
        "details": executive_result.get("details"),
        # Keep full executive object for future use
        "executive": executive_result
    }


def _generate_executive_summary(
    query: str,
    molecule: Optional[str],
    therapeutic_area: Optional[str],
    aggregated_results: Dict[str, Any],
    decision_result: Dict[str, Any]
) -> str:
    """
    Generate a 2-3 line executive summary of the analysis.
    
    Args:
        query: Original user query
        molecule: Optional molecule name
        therapeutic_area: Optional therapeutic area
        aggregated_results: Agent outputs
        decision_result: Decision gate result
        
    Returns:
        Executive summary string (2-3 lines)
    """
    decision_status = decision_result.get("decision", "Do Not Advance — Reallocation Advised")
    reasoning = decision_result.get("reasoning", "")
    confidence = decision_result.get("confidence", 50)
    
    # Build summary lines
    lines = []
    
    # Line 1: Context
    context_parts = []
    if therapeutic_area:
        context_parts.append(f"therapeutic area {therapeutic_area}")
    if molecule:
        context_parts.append(f"molecule {molecule}")
    context_str = " and ".join(context_parts) if context_parts else "the specified portfolio"
    
    # Map decision status to human-readable format
    decision_map = {
        "Advance Strategy Recommended": "strong portfolio potential",
        "Conditional Advancement Recommended": "moderate portfolio potential",
        "Do Not Advance — Reallocation Advised": "limited portfolio potential"
    }
    decision_text = decision_map.get(decision_status, "portfolio potential")
    
    lines.append(f"Analysis of {context_str} indicates {decision_text} ({confidence}% confidence).")
    
    # Line 2: Key findings
    key_findings = []
    if "market" in aggregated_results:
        key_findings.append("market intelligence")
    if "patent" in aggregated_results:
        key_findings.append("patent landscape")
    if "clinical" in aggregated_results:
        key_findings.append("clinical trial data")
    
    findings_str = ", ".join(key_findings) if key_findings else "comprehensive intelligence"
    lines.append(f"Assessment based on {findings_str} suggests {reasoning}")
    
    # Line 3: Recommendation (if space allows, otherwise combine with line 2)
    if decision_status == "Advance Strategy Recommended":
        lines.append("Recommendation: Proceed with portfolio advancement subject to execution discipline.")
    elif decision_status == "Conditional Advancement Recommended":
        lines.append("Recommendation: Conditional advancement recommended with targeted risk mitigation.")
    else:
        lines.append("Recommendation: Strategic resources should be redeployed to higher-opportunity areas.")
    
    return " ".join(lines)


# Master Agent logic completed – ready for EY Techathon demo.

