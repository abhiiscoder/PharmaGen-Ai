#!/usr/bin/env python
"""
Uvicorn entry point script for PharmaGen AI Backend.
This ensures stable module resolution regardless of working directory.
"""

import sys
import os
from pathlib import Path

# Ensure backend root is in Python path BEFORE importing app
_backend_root = Path(__file__).resolve().parent.absolute()
_backend_root_str = str(_backend_root)

if _backend_root_str not in sys.path:
    sys.path.insert(0, _backend_root_str)

os.environ.setdefault('PYTHONPATH', _backend_root_str)
if _backend_root_str not in os.environ.get('PYTHONPATH', '').split(os.pathsep):
    current_pythonpath = os.environ.get('PYTHONPATH', '')
    os.environ['PYTHONPATH'] = os.pathsep.join([_backend_root_str, current_pythonpath]) if current_pythonpath else _backend_root_str

# Now import app - this should work regardless of working directory
from app import app

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)

