#!/bin/bash

# Helper script to set up and run the PharmaGen AI backend

echo "Setting up PharmaGen AI Backend..."

# Create virtual environment if it doesn't exist
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Install dependencies
echo "Installing dependencies..."
pip install -r requirements.txt

# Create necessary directories
mkdir -p report_output
mkdir -p mock_data/internal_docs

# Run the server
echo "Starting FastAPI server..."
echo "Server will be available at http://localhost:8000"
echo "API docs available at http://localhost:8000/docs"
uvicorn app:app --reload --host 0.0.0.0 --port 8000







