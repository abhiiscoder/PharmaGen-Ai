"""
Test script for PharmaGen AI Backend flow.

Tests the complete analysis pipeline by calling the master agent directly
or through the FastAPI endpoint.
"""

import sys
import os
import json

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from master_agent import master_analyze


def test_master_agent():
    """Test the master agent with a sample payload."""
    print("=" * 80)
    print("PHARMAGEN AI BACKEND - TEST FLOW")
    print("=" * 80)
    print()
    
    # Sample test payload
    test_payload = {
        "query": "Analyze market opportunities for diabetes treatments",
        "molecule": "Metformin",
        "therapeutic_area": "Diabetes"
    }
    
    print("Test Payload:")
    print(json.dumps(test_payload, indent=2))
    print()
    print("-" * 80)
    print()
    
    try:
        print("Calling master_agent.master_analyze()...")
        print()
        
        result = master_analyze(test_payload)
        
        print("=" * 80)
        print("RESULT")
        print("=" * 80)
        print()
        print(f"Status: {result.get('status')}")
        print(f"Summary: {result.get('summary')}")
        print()
        print("Agent Outputs:")
        for agent_name, output in result.get('agent_outputs', {}).items():
            print(f"  - {agent_name}:")
            if isinstance(output, dict):
                print(f"    Summary: {output.get('summary', 'N/A')[:100]}...")
                print(f"    Data Points: {output.get('details', {}).get('data_points', 0)}")
            print()
        
        print(f"Report Path: {result.get('report_path')}")
        print()
        print("=" * 80)
        print("TEST COMPLETED SUCCESSFULLY")
        print("=" * 80)
        
        return True
        
    except Exception as e:
        print(f"ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


def test_with_different_payloads():
    """Test with multiple different payloads."""
    test_cases = [
        {
            "query": "What are the market trends for oncology drugs?",
            "molecule": "Pembrolizumab",
            "therapeutic_area": "Oncology"
        },
        {
            "query": "Analyze competitive landscape for cardiovascular drugs",
            "molecule": "Atorvastatin",
            "therapeutic_area": "Cardiovascular"
        },
        {
            "query": "General pharmaceutical market analysis",
            "molecule": None,
            "therapeutic_area": None
        }
    ]
    
    print("\n" + "=" * 80)
    print("RUNNING MULTIPLE TEST CASES")
    print("=" * 80 + "\n")
    
    for i, payload in enumerate(test_cases, 1):
        print(f"Test Case {i}:")
        print(f"  Query: {payload['query']}")
        print(f"  Molecule: {payload.get('molecule', 'N/A')}")
        print(f"  Therapeutic Area: {payload.get('therapeutic_area', 'N/A')}")
        print()
        
        try:
            result = master_analyze(payload)
            print(f"  ✓ Status: {result.get('status')}")
            print(f"  ✓ Agents executed: {len(result.get('agent_outputs', {}))}")
            print(f"  ✓ Report: {result.get('report_path', 'N/A')}")
        except Exception as e:
            print(f"  ✗ Error: {str(e)}")
        
        print()


if __name__ == "__main__":
    print("\n")
    
    # Run basic test
    success = test_master_agent()
    
    if success:
        # Run additional test cases
        test_with_different_payloads()
    
    print("\nTest script completed.\n")







