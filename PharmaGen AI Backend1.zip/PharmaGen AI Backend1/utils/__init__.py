"""Utility functions and helpers."""







