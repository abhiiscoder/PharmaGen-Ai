"""
Utility helper functions for logging, parsing, and data transformation.
"""

import logging
from typing import Dict, Any, List
from datetime import datetime


def setup_logging(level: int = logging.INFO) -> None:
    """
    Configure logging for the application.
    
    Args:
        level: Logging level (default: INFO)
    """
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )


def dict_to_table(data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convert a dictionary to a table-like structure for display.
    
    Args:
        data: Dictionary to convert
        
    Returns:
        Table structure with headers and rows
    """
    if not isinstance(data, dict):
        return {"headers": [], "rows": []}
    
    # If data is already in table format, return as-is
    if "headers" in data and "rows" in data:
        return data
    
    # Convert flat dict to table
    headers = list(data.keys())
    rows = [list(data.values())]
    
    return {
        "headers": headers,
        "rows": rows
    }


def list_to_table(data: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Convert a list of dictionaries to a table structure.
    
    Args:
        data: List of dictionaries
        
    Returns:
        Table structure with headers and rows
    """
    if not data or not isinstance(data, list):
        return {"headers": [], "rows": []}
    
    if not isinstance(data[0], dict):
        return {"headers": [], "rows": []}
    
    # Extract headers from first item
    headers = list(data[0].keys())
    
    # Extract rows
    rows = [[item.get(header, "") for header in headers] for item in data]
    
    return {
        "headers": headers,
        "rows": rows
    }


def format_timestamp() -> str:
    """
    Get current timestamp in ISO format.
    
    Returns:
        ISO formatted timestamp string
    """
    return datetime.now().isoformat()


def safe_get(data: Dict[str, Any], *keys, default: Any = None) -> Any:
    """
    Safely get nested dictionary values.
    
    Args:
        data: Dictionary to search
        *keys: Keys to traverse
        default: Default value if key not found
        
    Returns:
        Value at nested key or default
    """
    result = data
    for key in keys:
        if isinstance(result, dict):
            result = result.get(key, default)
        else:
            return default
    return result







