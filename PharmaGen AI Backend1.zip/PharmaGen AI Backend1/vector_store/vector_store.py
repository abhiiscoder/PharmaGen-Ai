"""
Vector Store - Placeholder for semantic search and document indexing.

Placeholder for Pinecone / FAISS / enterprise vector DB.
"""

from typing import List, Dict, Any
import logging
from difflib import SequenceMatcher

logger = logging.getLogger(__name__)


class VectorStore:
    """Lightweight in-memory semantic store using keyword overlap similarity."""
    
    def __init__(self):
        """Initialize the vector store."""
        self.documents: List[Dict[str, Any]] = []
        logger.info("Vector store initialized (in-memory placeholder)")
    
    def index_documents(self, docs: List[Dict[str, Any]]) -> None:
        """
        Store documents internally as a list.
        
        Each doc should have: {"id": str, "text": str, "source": str}
        Placeholder for Pinecone / FAISS / enterprise vector DB.
        
        Args:
            docs: List of document dictionaries with 'id', 'text', and 'source' keys
        """
        for doc in docs:
            if isinstance(doc, dict):
                # Ensure document has required fields
                if "id" not in doc:
                    # Generate ID if not provided
                    doc["id"] = f"doc_{len(self.documents)}"
                if "text" not in doc:
                    doc["text"] = str(doc.get("content", ""))
                if "source" not in doc:
                    doc["source"] = doc.get("metadata", {}).get("source", "unknown")
                
                # Store in standardized format
                self.documents.append({
                    "id": doc["id"],
                    "text": doc["text"],
                    "source": doc["source"]
                })
        
        logger.info(f"Indexed {len(docs)} documents (total: {len(self.documents)})")
    
    def semantic_search(self, query: str, top_k: int = 3) -> List[Dict[str, Any]]:
        """
        Implement simple similarity using keyword overlap.
        
        Placeholder for Pinecone / FAISS / enterprise vector DB.
        
        Args:
            query: Search query string
            top_k: Number of results to return
            
        Returns:
            List of top_k documents with fields: {"id", "text", "source"}
        """
        if not self.documents:
            logger.warning("Vector store is empty, returning empty results")
            return []
        
        # Simple keyword overlap similarity
        query_lower = query.lower()
        query_terms = set(query_lower.split())
        scored_docs = []
        
        for doc in self.documents:
            doc_text = doc.get("text", "").lower()
            doc_terms = set(doc_text.split())
            
            # Calculate keyword overlap ratio
            if len(query_terms) > 0:
                overlap = len(query_terms & doc_terms)
                term_overlap_score = overlap / len(query_terms)
            else:
                term_overlap_score = 0
            
            # Also use sequence similarity for partial matches
            similarity = SequenceMatcher(None, query_lower, doc_text[:500]).ratio()
            
            # Combined score (weighted towards keyword overlap)
            combined_score = (term_overlap_score * 0.7) + (similarity * 0.3)
            
            scored_docs.append({
                "id": doc["id"],
                "text": doc["text"],
                "source": doc["source"],
                "score": combined_score
            })
        
        # Sort by score and return top_k
        scored_docs.sort(key=lambda x: x["score"], reverse=True)
        results = scored_docs[:top_k]
        
        # Remove score from final results
        final_results = [
            {"id": r["id"], "text": r["text"], "source": r["source"]}
            for r in results
        ]
        
        logger.info(f"Semantic search for '{query}' returned {len(final_results)} results")
        
        return final_results


# Global instance
_vector_store = None


def get_vector_store() -> VectorStore:
    """Get or create the global vector store instance."""
    global _vector_store
    if _vector_store is None:
        _vector_store = VectorStore()
    return _vector_store


def index_documents(docs: List[Dict[str, Any]]) -> None:
    """Convenience function to index documents."""
    get_vector_store().index_documents(docs)


def semantic_search(query: str, top_k: int = 3) -> List[Dict[str, Any]]:
    """Convenience function for semantic search."""
    return get_vector_store().semantic_search(query, top_k)

